"""Petits widgets réutilisables qui ne rentrent pas ailleurs."""
from PyQt6.QtWidgets import QLineEdit, QLabel
from PyQt6.QtCore import Qt


class HistoryLineEdit(QLineEdit):
    """QLineEdit avec historique des commandes rappelable via les flèches
    Haut/Bas, comme un terminal classique. Utilisé pour le champ de
    commande manuelle GRBL."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._history = []
        self._history_index = -1

    def add_to_history(self, text):
        text = text.strip()
        if not text:
            return
        if not self._history or self._history[-1] != text:
            self._history.append(text)
        self._history_index = len(self._history)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Up:
            if self._history and self._history_index > 0:
                self._history_index -= 1
                self.setText(self._history[self._history_index])
            event.accept()
            return
        if event.key() == Qt.Key.Key_Down:
            # Déjà sur la ligne « nouvelle saisie » : Bas ne doit pas effacer
            # ce que l'utilisateur est en train de taper.
            if self._history and self._history_index < len(self._history):
                if self._history_index < len(self._history) - 1:
                    self._history_index += 1
                    self.setText(self._history[self._history_index])
                else:
                    self._history_index = len(self._history)
                    self.clear()
            event.accept()
            return
        super().keyPressEvent(event)


class AutoHideLabel(QLabel):
    """QLabel qui se masque tout seul quand son texte est vide et
    réapparaît dès qu'il contient quelque chose. Évite de garder un trou
    vide dans la mise en page pour les libellés d'état temporaires
    (ex. « Génération en cours… ») qui sont vides la plupart du temps."""

    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        # Ne masque que si vide : appeler setVisible(True) sur un label sans
        # parent l'afficherait comme une fenêtre isolée avant son layout.
        if not text:
            self.hide()

    def setText(self, text):
        super().setText(text)
        self.setVisible(bool(text))
