"""Génération, aperçu, estimation et export du G-Code."""
import re
from PyQt6.QtWidgets import (QFileDialog, QMessageBox)
from PyQt6.QtCore import Qt, QThread, QRectF
import pyqtgraph as pg
import numpy as np
from PIL import Image
from svg.path import parse_path
from laser_studio.vector_layers import (
    extract_vector_layer_data
)
from laser_studio.workers import AdvancedGCodeWorker, TestMatrixWorker, bidir_test_gcode, image_origin
from laser_studio.core.constants import ORIGIN_CENTER
from laser_studio.i18n import tr

BURN_COLOR = "#ff1a1a"     # traits déjà gravés pendant un job (aperçu 2D)

# Couleur du "matériau" simulé sous la gravure dans l'aperçu 2D normal (non négatif).
PREVIEW_MATERIAL_RGB = (225, 225, 225)


# Bornes de la vitesse (mm/min) et de la puissance (%) de gravure d'une image.
ENGRAVE_SPEED_RANGE = (10, 20000)
ENGRAVE_POWER_RANGE = (0, 100)
CUT_SPEED_RANGE = (10, 5000)
CUT_POWER_RANGE = (0, 100)
CUT_PASSES_RANGE = (0, 99)


def _clamp(value, bounds):
    low, high = bounds
    return min(max(int(value), low), high)


class GcodeGenerationMixin:
    def export_gcode_with_ext(self, extension):
        gcode_text = self.txt_console.toPlainText()

        if not gcode_text.strip():
            QMessageBox.warning(
                self,
                tr("gcode.empty_title"),
                tr("gcode.empty_export")
            )
            return

        file_filter = tr("gcode.file_filter").format(
            extension=extension
        )
        default_filename = f"job_laser{extension}"

        path, _ = QFileDialog.getSaveFileName(
            self,
            tr("gcode.export_title").format(
                extension=extension
            ),
            default_filename,
            file_filter
        )

        if path:
            if not path.lower().endswith(extension):
                path += extension

            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(gcode_text)

                QMessageBox.information(
                    self,
                    tr("gcode.export_success_title"),
                    tr("gcode.export_success").format(path=path)
                )

            except Exception as e:
                QMessageBox.critical(
                    self,
                    tr("gcode.export_error_title"),
                    tr("gcode.export_error").format(error=e)
                )

    def _plot_raster_reconstruction(self, raster_strokes, tint_color=None, gamma=1.0):
        """Reconstruit une vraie image en niveaux de gris (ou teintée avec la
        couleur du calque, si fournie) à partir des segments de gravure
        raster (position + puissance S), façon LaserGRBL, affichée sous les
        tracés vectoriels (découpe/calques).

        IMPORTANT : cette fonction ne doit être appelée qu'avec les segments
        d'UN SEUL calque à la fois (voir l'appelant) — mélanger plusieurs
        calques dans un même appel produirait une image bâtarde sans
        rapport avec ce qui est réellement gravé (chaque calque a sa propre
        étendue, sa propre densité de balayage, et parfois même une position
        totalement différente sur la pièce).

        Chaque ligne de balayage est placée à sa position Y RÉELLE et
        proportionnelle dans l'image (pas juste à un indice séquentiel) :
        sinon, un contenu avec de grands espaces vides entre motifs (ex: les
        carrés d'une matrice de test) voit ces espaces comprimés au même
        titre que les lignes de balayage très serrées à l'intérieur d'un
        motif, ce qui écrase et fait se chevaucher visuellement des zones
        qui sont en réalité bien séparées sur la pièce.

        `gamma` < 1 relève les faibles puissances (aperçu seulement, l'ordre des
        niveaux est conservé) : utile pour une matrice de test, où les cases peu
        puissantes seraient sinon presque invisibles.

        Note honnête : je n'ai pas pu exécuter PyQt6 dans cet environnement
        pour vérifier visuellement l'orientation (haut/bas) du résultat une
        fois affiché par pyqtgraph. Si l'image apparaît retournée, coche la
        case 'Inverser aperçu image' à côté du bouton Générer.
        """
        try:
            rows = {}
            for (x1, y1, x2, y2, s_val) in raster_strokes:
                y_key = round((y1 + y2) / 2.0, 4)
                rows.setdefault(y_key, []).append((min(x1, x2), max(x1, x2), s_val))

            row_ys = sorted(rows.keys())
            if len(row_ys) < 2:
                return

            all_x = [seg[0] for segs in rows.values() for seg in segs] + \
                    [seg[1] for segs in rows.values() for seg in segs]
            min_x, max_x = min(all_x), max(all_x)
            bbox_w = max(max_x - min_x, 0.01)

            min_y_data, max_y_data = row_ys[0], row_ys[-1]
            bbox_h = max(max_y_data - min_y_data, 0.01)

            target_cols = 1200
            px_per_mm_x = target_cols / bbox_w
            img_w = max(1, int(round(bbox_w * px_per_mm_x)))

            # La densité verticale doit être calée sur l'écart RÉEL entre
            # deux lignes de balayage consécutives (pas sur une densité
            # dérivée de la largeur totale) : sinon, dès que le contenu a
            # plusieurs motifs séparés en largeur (ex: les colonnes d'une
            # matrice de test), la densité verticale déduite de la largeur
            # totale est bien plus grossière que le pas de balayage réel —
            # certaines lignes de sortie ne reçoivent alors aucune ligne
            # source (restent blanches) pendant que d'autres en reçoivent
            # plusieurs, créant un effet de bandes/hachures horizontales.
            row_gaps = [b - a for a, b in zip(row_ys[:-1], row_ys[1:]) if b - a > 0.001]
            min_row_spacing = min(row_gaps) if row_gaps else bbox_h
            px_per_mm_y_needed = 1.0 / min_row_spacing
            img_h = max(1, min(6000, int(round(bbox_h * px_per_mm_y_needed))))
            px_per_mm_y = img_h / bbox_h

            s_all = [seg[2] for segs in rows.values() for seg in segs if seg[2]]
            max_s = max(s_all) if s_all else 1.0
            if max_s <= 0:
                max_s = 1.0

            # power[ligne, colonne] : puissance normalisée (0-1). ligne 0 =
            # Y le plus petit (bas de la gravure). On combine les
            # chevauchements avec un maximum (la puissance la plus forte
            # gagne visuellement), pas une moyenne.
            power_arr = np.zeros((img_h, img_w), dtype=np.float32)
            for y_key in row_ys:
                row_idx = int(round((y_key - min_y_data) * px_per_mm_y))
                row_idx = max(0, min(img_h - 1, row_idx))
                for (xa, xb, s_val) in rows[y_key]:
                    if not s_val or s_val <= 0:
                        continue
                    power = min(max(s_val / max_s, 0.0), 1.0)
                    col_a = max(0, min(img_w - 1, int(round((xa - min_x) * px_per_mm_x))))
                    col_b = max(col_a + 1, min(img_w, int(round((xb - min_x) * px_per_mm_x)) + 1))
                    np.maximum(power_arr[row_idx, col_a:col_b], power, out=power_arr[row_idx, col_a:col_b])

            if gamma != 1.0:
                power_arr = np.power(power_arr, gamma, dtype=np.float32)

            negative_preview = bool(getattr(self, "chk_negative_raster_preview", None)
                                     and self.chk_negative_raster_preview.isChecked())
            if negative_preview:
                power_arr = 1.0 - power_arr  # négatif : plus de puissance = plus clair

            # Les zones sans puissance doivent rester transparentes.
            # Sinon l'ImageItem crée un grand rectangle blanc autour de la
            # gravure importée, ce qui masque le fond et les autres tracés.
            #
            # La puissance sert à la fois :
            # - à déterminer l'intensité de la couleur ;
            # - à déterminer l'opacité du pixel.
            #
            # Ainsi, seuls les déplacements réellement gravés sont visibles.

            if negative_preview:
                # En mode négatif, on conserve volontairement un rendu
                # opaque pour que l'inversion reste lisible.
                if tint_color:
                    tint_rgb = pg.mkColor(tint_color).getRgb()[:3]
                    white = np.array([255, 255, 255], dtype=np.float32)
                    tint = np.array(tint_rgb, dtype=np.float32)
                    blend = power_arr[..., None]
                    rgb = white + blend * (tint - white)
                    arr = np.clip(rgb, 0, 255).astype(np.uint8)
                else:
                    gray = 255 * (1.0 - power_arr)
                    arr = np.clip(gray, 0, 255).astype(np.uint8)

                pg_array = (
                    arr.transpose(1, 0, 2)
                    if tint_color
                    else arr.T
                )

            else:
                # Rendu "normal" : la gravure est simulée sur un matériau
                # clair (fond opaque gris clair, brûlure noire ou teintée).
                # Avant, le rendu était transparent avec une gravure NOIRE
                # posée sur le fond sombre du graphique : illisible. Le
                # rectangle opaque reste sous les tracés (zValue -50), donc
                # les découpes / contours restent visibles par-dessus.
                material = np.array(PREVIEW_MATERIAL_RGB, dtype=np.float32)
                if tint_color:
                    burn = np.array(pg.mkColor(tint_color).getRgb()[:3], dtype=np.float32)
                else:
                    burn = np.zeros(3, dtype=np.float32)
                blend = power_arr[..., None]
                rgb = material + blend * (burn - material)
                arr = np.clip(rgb, 0, 255).astype(np.uint8)
                pg_array = arr.transpose(1, 0, 2)
            if getattr(self, "chk_flip_raster_preview", None) and self.chk_flip_raster_preview.isChecked():
                pg_array = pg_array[:, ::-1] if not tint_color else pg_array[:, ::-1, :]

            image_item = pg.ImageItem(pg_array)

            # Tous les rendus sont maintenant opaques et déjà à l'échelle
            # 0-255 : on fige les niveaux pour éviter tout étirement de
            # contraste automatique de pyqtgraph.
            image_item.setLevels([0, 255])
            image_item.setRect(QRectF(min_x, min_y_data, bbox_w, bbox_h))
            image_item.setZValue(-50)
            # Sans ça, pyqtgraph affiche l'image dézoomée en échantillonnant
            # un pixel source sur N au hasard (plus-proche-voisin) plutôt
            # qu'en moyennant : sur du tramage fin noir/blanc, ça donne un
            # bruit gris illisible tant qu'on n'a pas zoomé fort. Avec le
            # downsampling automatique, pyqtgraph fait une vraie moyenne des
            # pixels à l'affichage, donnant un aperçu correct dès la vue
            # d'ensemble (comme LaserGRBL), sans perdre le détail au zoom.
            image_item.setAutoDownsample(True)
            self.plot_widget.addItem(image_item)
        except Exception as e:
            self.log_message(f"; Aperçu image raster indisponible : {e}")

    def _format_duration(self, seconds):
        seconds = max(0, int(seconds))
        h, rem = divmod(seconds, 3600)
        m, s = divmod(rem, 60)
        if h > 0:
            return f"{h}h {m:02d}min"
        return f"{m}min {s:02d}s"

    def estimate_job_time(self):
        """Estimation RAPIDE du temps de gravure/découpe, sans générer le
        G-Code complet : utile pour ajuster vitesse/résolution avant de
        lancer un calcul complet (qui peut prendre du temps sur une grande
        image). Approximatif par nature (ignore accélérations/G0)."""
        total_seconds = 0.0
        details = []

        if self.processed_array is not None:
            w_mm = self.spin_w.value()
            speed = self.engrave_speed
            # Surbalayage de chaque côté d'une ligne, comme à la génération (AdvancedGCodeWorker) :
            # désactivé, distance fixe ou pourcentage de la largeur de l'image.
            if self.chk_overscan.isChecked():
                if self._overscan_mode_value() == "Pourcentage (%)":
                    overscan = w_mm * self.spin_overscan_pct.value() / 100.0
                else:
                    overscan = self.spin_overscan_dist.value()
            else:
                overscan = 0.0
            # Comme la génération : lignes vides sautées, chaque ligne balayée de son premier à son
            # dernier pixel gravé, plus le surbalayage.
            burned = np.asarray(self.processed_array) < 255
            swept = burned.any(axis=1)
            first = burned.argmax(axis=1)
            last = burned.shape[1] - 1 - burned[:, ::-1].argmax(axis=1)
            step_x = w_mm / max(burned.shape[1], 1)
            distance = float(((last + 1 - first) * step_x + 2 * overscan)[swept].sum())
            t = (distance / max(speed, 1)) * 60.0
            total_seconds += t
            details.append(tr("gcode.image_details").format(
                duration=self._format_duration(t)
            ))

        if self.loaded_svg_path:
            try:
                from svg.path import parse_path
                import xml.etree.ElementTree as ET
                tree = ET.parse(self.loaded_svg_path)
                total_len_svg = 0.0
                for elem in tree.iter():
                    d = elem.attrib.get('d')
                    if d:
                        try:
                            total_len_svg += parse_path(d).length(error=1e-3)
                        except Exception:
                            pass
                speed_cut = self.cut_speed
                passes_cut = self.cut_passes
                t = (total_len_svg / max(speed_cut, 1)) * 60.0 * passes_cut
                total_seconds += t
                details.append(tr("gcode.svg_details").format(
                    duration=self._format_duration(t)
                ))
            except Exception:
                pass

        if hasattr(self, 'vector_canvas'):
            for layer in self.layer_manager.layers:
                if not layer.enabled:
                    continue
                objs = [o for o in self.vector_canvas.objects if o.layer_id == layer.id]
                if not objs:
                    continue
                if layer.mode == "Gravure Remplie":
                    total_area = sum(o.world_path().boundingRect().width() *
                                      o.world_path().boundingRect().height() for o in objs)
                    length_est = total_area / max(layer.line_interval, 0.02)
                    t = (length_est / max(layer.speed, 1)) * 60.0
                else:
                    total_len = sum(o.world_path().length() for o in objs)
                    t = (total_len / max(layer.speed, 1)) * 60.0 * max(layer.passes, 1)
                total_seconds += t
                details.append(tr("gcode.layer_details").format(
                    name=layer.name,
                    duration=self._format_duration(t)
                ))

        if total_seconds == 0.0:
            QMessageBox.information(
                self,
                tr("gcode.estimate_title"),
                tr("gcode.nothing_to_estimate")
            )
            return

        msg = tr("gcode.estimate_details").format(
            details="\n".join(details),
            total=self._format_duration(total_seconds)
        )

        QMessageBox.information(
            self,
            tr("gcode.estimate_title_full"),
            msg
        )

    def import_gcode_file(self):
        """Importe un fichier G-Code existant (généré par un autre outil : LaserGRBL,
        le multi-générateur kpc29laser/MGL, un export G-Code de LightBurn, etc.) pour
        l'afficher dans la console et le visualiser dans l'aperçu 2D, sans passer par
        le pipeline de génération interne (image/vecteurs) de l'application."""
        path, _ = QFileDialog.getOpenFileName(
            self,
            tr("gcode.import_title"),
            "",
            tr("gcode.import_filter")
        )
        if not path:
            return
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                gcode_text = f.read()
        except Exception as e:
            QMessageBox.critical(
                self,
                tr("gcode.export_error_title"),
                tr("gcode.import_error").format(error=e)
            )
            return

        self.txt_console.setPlainText(gcode_text)
        num_lines = len([l for l in gcode_text.split('\n') if l.strip()])
        self.tab_vector_2d.job_stats_panel.set_stats(tr("gen.stat_lines").format(n=num_lines),
                                                     tr("gen.stat_power_imported"),
                                                     tr("gen.stat_time_imported"))
        self.plot_gcode_preview(gcode_text)
        # « Fichier > Enregistrer le G-Code » : le G-Code importé peut être réenregistré.
        self.app_actions.set_gcode_export_enabled(True)
        self.main_tabs_view.setCurrentWidget(self.tab_vector_2d)
        self.log_message(
    tr("gcode.imported_from").format(path=path)
)

    def _overscan_mode_value(self):
        """Mode de surbalayage sous une forme indépendante de la langue : les
        libellés du menu sont traduits, alors que le générateur de G-Code
        compare à « Pourcentage (%) » (avant, le mode pourcentage n'était pas
        reconnu en anglais, allemand et espagnol)."""
        return "Pourcentage (%)" if self.combo_overscan_mode.currentIndex() == 1 else "Distance Fixe (mm)"

    def _build_gcode_params(self):
        """Paramètres de génération du G-Code, lus depuis l'interface."""
        return {
            'width_mm': self.spin_w.value(),
            'height_mm': self.spin_h.value(),
            'origin_pos': self.job_position_box.origin(),
            'offset_x': self.spin_off_x.value(),
            'offset_y': self.spin_off_y.value(),
            'speed_engrave': self.engrave_speed,
            'power_engrave': self.engrave_power,
            'enable_cut': self.cut_enabled,
            'speed_cut': self.cut_speed,
            'power_cut': self.cut_power,
            'passes_cut': self.cut_passes,
            'laser_cmd': self.combo_laser_cmd.currentText().split()[0],
            'algo': self.combo_algo.currentText(),
            's_max': self.spin_smax.value(),
            'homing': self.chk_homing.isChecked(),
            'enable_overscan': self.chk_overscan.isChecked(),
            'overscan_mode': self._overscan_mode_value(),
            'overscan_dist': self.spin_overscan_dist.value(),
            'overscan_pct': self.spin_overscan_pct.value(),
            'start_gcode': self.txt_start_gcode.toPlainText(),
            'end_gcode': self.txt_end_gcode.toPlainText(),
            # Décalage des lignes retour (mm), propre à la machine : voir workers.py.
            'scan_offset_mm': self.spin_scan_offset.value() if hasattr(self, "spin_scan_offset") else 0.0,
            # Graver avant de découper ; intérieurs avant extérieurs (voir vector/order.py).
            'safe_cut_order': self.chk_safe_cut_order.isChecked() if hasattr(self, "chk_safe_cut_order") else True,
        }

    def generate_bidir_test(self):
        """Génère le motif de calibrage du décalage aller/retour (voir
        workers.bidir_test_gcode) avec la vitesse, la puissance et la résolution
        actuelles, puis l'affiche comme n'importe quel G-Code généré."""
        if self.chk_overscan.isChecked():
            overscan = self.spin_overscan_dist.value() if self.combo_overscan_mode.currentIndex() == 0 else 2.5
        else:
            overscan = 0.0
        params = {
            'origin_pos': self.job_position_box.origin(),
            'offset_x': self.spin_off_x.value(),
            'offset_y': self.spin_off_y.value(),
            'speed_engrave': self.engrave_speed,
            'power_engrave': self.engrave_power,
            's_max': self.spin_smax.value(),
            'laser_cmd': self.combo_laser_cmd.currentText().split()[0],
            'homing': self.chk_homing.isChecked(),
            'start_gcode': self.txt_start_gcode.toPlainText(),
            'end_gcode': self.txt_end_gcode.toPlainText(),
            'overscan_dist': overscan,
            'line_pitch_mm': 1.0 / max(self.spin_lmm.value(), 0.1),
        }
        gcode, n_lines, avg_power, time_str = bidir_test_gcode(params)
        # La matrice de test mémorisée ne correspond plus au G-Code affiché.
        self.last_test_matrix_params = None
        self.on_gcode_generated(gcode, n_lines, avg_power, time_str)
        QMessageBox.information(self, tr("gen.bidir_test_title"), tr("gen.bidir_test_body"))

    def set_engrave_settings(self, speed, power):
        """Vitesse (mm/min) et puissance (%) de la gravure d'une image.

        Valeurs entières, ramenées dans ENGRAVE_SPEED_RANGE et
        ENGRAVE_POWER_RANGE.
        """
        self.engrave_speed = _clamp(speed, ENGRAVE_SPEED_RANGE)
        self.engrave_power = _clamp(power, ENGRAVE_POWER_RANGE)

    def set_cut_settings(self, speed, power, passes):
        """Vitesse (mm/min), puissance (%) et passes de la découpe de
        l'ancien mode SVG.

        Valeurs entières, ramenées dans CUT_SPEED_RANGE, CUT_POWER_RANGE
        et CUT_PASSES_RANGE.
        """
        self.cut_speed = _clamp(speed, CUT_SPEED_RANGE)
        self.cut_power = _clamp(power, CUT_POWER_RANGE)
        self.cut_passes = _clamp(passes, CUT_PASSES_RANGE)

    def generate_job(self):
        try:
            self._generate_job_impl()
        except Exception as e:
            import traceback
            error_text = f"{e}\n\n{traceback.format_exc()}"
            self.statusBar().hide_progress()
            self.log_message(f"\n; ERREUR AVANT GÉNÉRATION :\n; {error_text}")
            QMessageBox.critical(self, tr("laser.error"), tr("gen.start_failed").format(error=error_text))

    def _generate_job_impl(self):
        # Image (tramage / séparation couleur) : toujours en mode gravure par
        # défaut, avant la lecture des vitesses/puissances ci-dessous.
        if self.processed_array is not None:
            self._ensure_engrave_layer_for_image()
        job_w = self.spin_w.value()
        job_h = self.spin_h.value()
        bed_w = self.spin_machine_w.value()
        bed_h = self.spin_machine_h.value()
        if job_w > bed_w or job_h > bed_h:
            QMessageBox.warning(
                self, tr("gen.too_big_title"),
                tr("gen.too_big_body").format(
                    job_w=job_w, job_h=job_h, bed_w=bed_w, bed_h=bed_h,
                    tab_machine=tr("tab.machine_params"), tab_dims=tr("ui.tab_image_tracing"),
                )
            )
            return

        max_speed_limit = self.spin_machine_max_speed.value()
        speeds_to_check = [(tr("gen.speed_row_engrave"), self.engrave_speed)]
        if self.cut_enabled:
            speeds_to_check.append((tr("gen.speed_row_cut_old"), self.cut_speed))
        for layer in self.layer_manager.layers:
            if layer.enabled:
                speeds_to_check.append((tr("gen.speed_row_layer").format(name=layer.name), layer.speed))
        over_limit = [(name, spd) for name, spd in speeds_to_check if spd > max_speed_limit]
        if over_limit:
            details = "\n".join(f"  • {name} : {spd:.0f} mm/min" for name, spd in over_limit)
            reply = QMessageBox.warning(
                self, tr("gen.speed_limit_title"),
                tr("gen.speed_limit_body").format(
                    limit=max_speed_limit, details=details,
                    tab_machine=tr("tab.machine_params"),
                ),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        has_image = self.processed_array is not None
        has_vector_objects = hasattr(self, "vector_canvas") and len(self.vector_canvas.objects) > 0
        if has_image and has_vector_objects:
            layer_names = sorted(set(
                self.layer_manager.get(o.layer_id).name
                for o in self.vector_canvas.objects
                if self.layer_manager.get(o.layer_id)
            ))
            summary = (
                tr("gen.confirm_image") + "\n"
                + tr("gen.confirm_vectors").format(
                    count=len(self.vector_canvas.objects),
                    layers=len(layer_names),
                    names=', '.join(layer_names) if layer_names else '—',
                )
            )
            reply = QMessageBox.question(
                self, tr("gen.confirm_title"),
                tr("gen.confirm_body").format(summary=summary),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Yes
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        params = self._build_gcode_params()

        if params['enable_overscan'] and self.processed_array is not None:
            if params['overscan_mode'] == "Pourcentage (%)":
                overscan_check = params['width_mm'] * (params['overscan_pct'] / 100.0)
            else:
                overscan_check = params['overscan_dist']

            base_x_check = image_origin(params)[0]

            if base_x_check - overscan_check < 0:
                QMessageBox.critical(
                    self, tr("gen.overscan_title"),
                    tr("gen.overscan_body").format(
                        overscan=overscan_check, offset=params['offset_x'],
                        start=base_x_check - overscan_check,
                        tab_dims=tr("ui.tab_image_tracing"), tab_grbl=tr("tab.grbl_config"),
                    )
                )
                return

        # Extraction géométrique des calques vectoriels (texte/formes) : se fait
        # ici dans le thread principal (Qt requis), le résultat est du texte/nombres
        # purs, sans risque pour le QThread qui va s'en servir.
        vector_layers_data = extract_vector_layer_data(
            self.vector_canvas.objects, self.layer_manager,
            optimize_path=getattr(self, "chk_optimize_path", None) is None or self.chk_optimize_path.isChecked(),
        ) if hasattr(self, "vector_canvas") else {}

        if params['enable_overscan'] and hasattr(self, "vector_canvas"):
            if params['overscan_mode'] == "Pourcentage (%)":
                vec_overscan_check = params['width_mm'] * (params['overscan_pct'] / 100.0)
            else:
                vec_overscan_check = params['overscan_dist']

            for layer_id, data in vector_layers_data.items():
                layer = data["layer"]
                if layer["mode"] != "Gravure Remplie" or not data["polygons"]:
                    continue
                min_x = min(p[0] for poly in data["polygons"] for p in poly)
                base_x = params['offset_x'] - (params['width_mm'] / 2.0) if params['origin_pos'] == ORIGIN_CENTER else params['offset_x']
                if base_x + min_x - vec_overscan_check < 0:
                    QMessageBox.critical(
                        self, tr("gen.overscan_vec_title"),
                        tr("gen.overscan_vec_body").format(
                            name=layer['name'], overscan=vec_overscan_check,
                            start=base_x + min_x - vec_overscan_check,
                            tab_grbl=tr("tab.grbl_config"),
                        )
                    )
                    return

        # Dernier garde-fou avant de générer une gravure image : rappel de la
        # puissance et de la vitesse, comme l'alerte de surbalayage ci-dessus.
        if self.processed_array is not None:
            layer_label = self._engrave_layer_label()
            reply = QMessageBox.question(
                self, tr("gen.engrave_confirm_title"),
                tr("gen.engrave_confirm_body").format(
                    layer=layer_label or "—",
                    power=params['power_engrave'],
                    speed=params['speed_engrave'],
                    width=params['width_mm'],
                    height=params['height_mm'],
                    material=self.material_summary_text(),
                ),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Yes
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        self.worker = AdvancedGCodeWorker(self.processed_array, self.loaded_svg_path, params, vector_layers_data)
        self.worker.finished.connect(self.on_gcode_generated)
        self.worker.progress.connect(self.on_gcode_generation_progress)
        self.worker.error.connect(self.on_gcode_generation_error)
        self.statusBar().show_progress(0, tr("gen.in_progress"))
        # On montre l'aperçu dès le lancement (il se remplit à la fin, voir on_gcode_generated).
        self.main_tabs_view.setCurrentWidget(self.tab_vector_2d)
        self.worker.start()

    def on_gcode_generation_error(self, error_text):
        self.statusBar().hide_progress()
        self.log_message(f"\n; ERREUR DE GÉNÉRATION :\n; {error_text}")
        QMessageBox.critical(self, tr("gen.failed_title"), tr("gen.failed_body").format(error=error_text))

    def on_gcode_generation_progress(self, pct):
        self.statusBar().show_progress(pct, tr("gen.in_progress_pct").format(pct=pct))

    def generate_test_matrix(self):
        """Lance la génération de la matrice de test. Renvoie True si elle a
        démarré, False sinon (zone d'image impossible, message affiché)."""
        # Sécurité : lignes/mm toujours identique à l'onglet Image / Filtre.
        self._sync_matrix_lmm_from_image()
        # Mode indépendant de la langue : currentText() est traduit (« Engraving », « Gravur »…),
        # alors que le générateur et _on_plot_clicked comparent à « Gravure ».
        page = self.tab_matrix
        engraving = page.is_engraving()
        params = page.matrix_params()
        params.update({
            'mode': "Gravure" if engraving else "Découpe",
            's_max': self.spin_smax.value(),
            'enable_overscan': self.chk_overscan.isChecked(),
            'overscan_mode': self._overscan_mode_value(),
            'overscan_dist': self.spin_overscan_dist.value(),
            'overscan_pct': self.spin_overscan_pct.value(),
            # Décalage des lignes retour (réglage machine), comme pour une gravure d'image.
            'scan_offset_mm': self.spin_scan_offset.value() if hasattr(self, "spin_scan_offset") else 0.0,
        })
        # Test à partir d'une image : chaque case grave la zone choisie au lieu d'un carré plein.
        if engraving and page.image_test_enabled():
            tile = self.matrix_image.build_tile(params['lines_mm'])
            if tile is None:
                return False
            params['image_tile'] = tile
            params['cell_w'] = tile['w_mm']
            params['cell_h'] = tile['h_mm']
        # Mémorisé pour permettre le clic sur une case de l'aperçu 2D
        # (voir _on_plot_clicked) afin d'appliquer directement sa
        # puissance/vitesse aux réglages de gravure/découpe courants.
        self.last_test_matrix_params = dict(params)

        self.matrix_worker = TestMatrixWorker(params)
        self.matrix_worker.finished.connect(self.on_gcode_generated)
        self.matrix_worker.start()
        return True

    def _on_plot_clicked(self, x_mm, y_mm):
        """Clic sur l'aperçu 2D : si le G-Code affiché est bien la dernière
        matrice de test générée, retrouve la case cliquée et applique sa
        puissance/vitesse (ou nombre de passes) aux réglages de gravure ou
        de découpe courants — évite de retaper les valeurs à la main une
        fois la case idéale repérée visuellement."""
        params = getattr(self, "last_test_matrix_params", None)
        if not params:
            return
        try:
            offset_labels_x, offset_labels_y = 22.0, 14.0
            mat_off_x = params.get('matrix_offset_x', 0.0)
            mat_off_y = params.get('matrix_offset_y', 0.0)
            start_x = mat_off_x + offset_labels_x
            start_y = mat_off_y + offset_labels_y
            # Case : carré, ou zone d'image (largeur x hauteur) pour un test à partir d'une image.
            cell_w = float(params.get('cell_w') or params['size_square'])
            cell_h = float(params.get('cell_h') or params['size_square'])
            gap = params['gap']

            min_s, max_s, steps_s = params['min_speed'], params['max_speed'], int(params['steps_speed'])
            speeds = np.linspace(min_s, max_s, steps_s)

            mode = params.get('mode', 'Gravure')
            if mode == "Gravure":
                min_p, max_p, steps_p = params['min_power'], params['max_power'], int(params['steps_power'])
                col_values = np.linspace(min_p, max_p, steps_p)
            else:
                min_pa, max_pa, steps_pa = params['min_passes'], params['max_passes'], int(params['steps_passes'])
                col_values = np.unique(np.round(np.linspace(min_pa, max_pa, steps_pa))).astype(int)

            col = int((x_mm - start_x) // (cell_w + gap))
            row = int((y_mm - start_y) // (cell_h + gap))
            if not (0 <= col < len(col_values) and 0 <= row < len(speeds)):
                return
            cell_x0 = start_x + col * (cell_w + gap)
            cell_y0 = start_y + row * (cell_h + gap)
            if not (cell_x0 <= x_mm <= cell_x0 + cell_w and cell_y0 <= y_mm <= cell_y0 + cell_h):
                return  # clic dans l'espace entre les cases, pas dans une case

            speed_val = round(float(speeds[row]))
            if mode == "Gravure":
                power_val = round(float(col_values[col]))
                self.set_engrave_settings(speed_val, power_val)
                self.log_message(f">>> Case matrice appliquée : {speed_val} mm/min, {power_val}% (gravure)")
            else:
                passes_val = int(col_values[col])
                self.set_cut_settings(speed_val, round(params.get('single_power', self.cut_power)), passes_val)
                self.log_message(f">>> Case matrice appliquée : {speed_val} mm/min, {passes_val} passe(s) (découpe)")
        except Exception:
            pass  # un clic hors matrice ou une erreur de calcul ne doit jamais planter l'appli

    def on_gcode_generated(self, gcode_str, num_lines, avg_power, time_str):
        self.statusBar().show_progress(100, tr("gen.done"))
        self.statusBar().hide_progress(delay_ms=1500)
        self.txt_console.setPlainText(gcode_str)
        self.tab_vector_2d.job_stats_panel.set_stats(tr("gen.stat_lines").format(n=num_lines),
                                                     tr("gen.stat_power").format(value=f"{avg_power:.1f}"),
                                                     tr("gen.stat_time").format(value=time_str))
        # « Fichier > Enregistrer le G-Code » : actif une fois le G-Code généré.
        self.app_actions.set_gcode_export_enabled(True)
        self.plot_gcode_preview(gcode_str)
        
        self.main_tabs_view.setCurrentWidget(self.tab_vector_2d)

    def update_gcode_position_marker(self, x, y):
        """Met à jour le marqueur de position temps réel (DRO) affiché sur
        l'aperçu 2D G-Code, à partir de la position machine renvoyée par
        GRBL (MPos ou WPos selon le réglage $10 du firmware). Remarque :
        aucune compensation d'un éventuel décalage G92/G54 n'est appliquée
        ici — ce marqueur est un repère visuel approximatif de suivi de
        job, pas une mesure de précision.
        """
        if not hasattr(self, "gcode_position_marker"):
            return
        self.gcode_position_marker.setData([x], [y])

    # ------------------------------------------------------------------
    # Gravure en temps réel sur l'aperçu 2D : les traits gravés passent en rouge
    # ------------------------------------------------------------------
    BURN_WINDOW = 200          # traits examinés au plus autour de la position de la tête
    BURN_ON_PATH_MM = 0.5      # distance tête / trait en dessous de laquelle la tête est « sur » le trait
    BURN_PLANNER_LEAD = 15     # mouvements que GRBL peut avoir acceptés (« ok ») sans les avoir faits

    def _setup_burn_overlay(self, burn_line_idx, burn_segments):
        """Prépare le calque rouge « déjà gravé » pour le G-Code qui vient d'être dessiné."""
        self._burn_line_idx = np.asarray(burn_line_idx, dtype=np.int64)
        self._burn_segs = np.asarray(burn_segments, dtype=float).reshape(-1, 4)
        n = len(self._burn_segs)
        # Données prêtes à tracer : x1, x2, NaN pour chaque trait (même format que l'aperçu).
        self._burn_xs = np.column_stack([self._burn_segs[:, 0], self._burn_segs[:, 2], np.full(n, np.nan)]).ravel()
        self._burn_ys = np.column_stack([self._burn_segs[:, 1], self._burn_segs[:, 3], np.full(n, np.nan)]).ravel()
        self._burn_done = 0
        self._stream_acked = 0
        self.burn_overlay = pg.PlotDataItem(pen=pg.mkPen(color=BURN_COLOR, width=2.2), connect="finite")
        self.burn_overlay.setZValue(900)               # au-dessus des tracés, sous le point rouge
        self.plot_widget.addItem(self.burn_overlay, ignoreBounds=True)

    def reset_burn_overlay(self):
        """Nouveau job sur le même G-Code : plus rien n'est gravé."""
        if getattr(self, "burn_overlay", None) is None:
            return
        self._burn_done = 0
        self._stream_acked = 0
        self.burn_overlay.setData([], [])

    def on_lines_acked(self, acked):
        """Reçu de GCodeStreamerThread.lines_acked : lignes acceptées par GRBL jusqu'ici."""
        self._stream_acked = acked

    def update_burn_overlay(self, x, y):
        """Avance le calque rouge d'après la position de la tête (rapport d'état GRBL).

        Les « ok » disent jusqu'à quelle ligne GRBL a pu aller : la tête est sur un des traits
        acceptés et pas encore marqués gravés. On prend le plus proche d'elle (le premier en cas
        d'égalité, pour les passes superposées) : les traits précédents sont gravés, et celui-ci
        l'est jusqu'à la tête. Si la tête n'est sur aucun trait (déplacement à vide, surbalayage,
        position décalée par G92), on avance au moins jusqu'aux traits que GRBL a forcément
        terminés (les « ok » moins les mouvements qu'il peut garder en mémoire)."""
        overlay = getattr(self, "burn_overlay", None)
        segs = getattr(self, "_burn_segs", None)
        if overlay is None or segs is None or not len(segs):
            return
        done = self._burn_done
        accepted = int(np.searchsorted(self._burn_line_idx, self._stream_acked))  # traits acceptés par GRBL
        partial = None
        done = max(done, accepted - self.BURN_PLANNER_LEAD)
        hi = min(accepted, done + self.BURN_WINDOW)
        if hi > done:
            window = segs[done:hi]
            ax, ay, bx, by = window[:, 0], window[:, 1], window[:, 2], window[:, 3]
            dx, dy = bx - ax, by - ay
            length2 = dx * dx + dy * dy
            t = np.where(length2 > 0, ((x - ax) * dx + (y - ay) * dy) / np.where(length2 > 0, length2, 1), 0.0)
            t = np.clip(t, 0.0, 1.0)
            px, py = ax + t * dx, ay + t * dy
            dist = np.hypot(x - px, y - py)
            best = float(dist.min())
            if best <= self.BURN_ON_PATH_MM:
                k = int(np.flatnonzero(dist <= best + 0.05)[0])
                done += k
                partial = (ax[k], ay[k], px[k], py[k])
        self._burn_done = done
        self._draw_burn_overlay(partial)

    def finish_burn_overlay(self, clean_finish):
        """Fin du job : tout est gravé si le job s'est terminé normalement, sinon le calque rouge
        reste tel quel (il montre jusqu'où la gravure est allée)."""
        if clean_finish and getattr(self, "_burn_segs", None) is not None:
            self._burn_done = len(self._burn_segs)
            self._draw_burn_overlay(None)

    def _draw_burn_overlay(self, partial):
        n = 3 * self._burn_done
        xs, ys = self._burn_xs[:n], self._burn_ys[:n]
        if partial is not None:
            ax, ay, px, py = partial
            xs = np.concatenate([xs, [ax, px, np.nan]])
            ys = np.concatenate([ys, [ay, py, np.nan]])
        self.burn_overlay.setData(xs, ys, connect="finite")

    def plot_gcode_preview(self, gcode_text):
        self._last_gcode_text = gcode_text
        try:
            self._plot_gcode_preview_impl(gcode_text)
        except Exception as e:
            # Ne jamais laisser l'aperçu 2D silencieusement vide : si le G-Code
            # (notamment un fichier importé d'un autre outil) contient une
            # ligne inattendue qui fait planter l'analyse, on le signale
            # clairement dans la console plutôt que d'afficher un graphique vide.
            self.log_message(f"\n; ERREUR aperçu 2D : {e}")
            QMessageBox.warning(self, tr("gen.preview_error_title"),
                                 tr("gen.preview_error_body").format(error=e))

    def _plot_gcode_preview_impl(self, gcode_text):
        self.plot_widget.clear()

        # Chaque phase (image / découpe SVG) et chaque calque vectoriel est
        # tracé avec sa propre couleur, repérable via les marqueurs de
        # commentaires déjà présents dans le G-Code généré.
        DEFAULT_SVG_COLOR = "#ff00ff"
        DEFAULT_LAYER_COLOR = "#00ff88"
        RASTER_LABEL = tr("gen.legend_raster")
        MATRIX_LABEL = tr("gen.legend_test_matrix")
        UNKNOWN_LABEL = tr("gen.legend_unknown")

        current_label = UNKNOWN_LABEL
        current_color = "#00ff88"
        current_layer_mode = None
        current_is_test_matrix = False

        g0_x, g0_y = [], []
        ov_x, ov_y = [], []
        g1_travel_x, g1_travel_y = [], []  # G1 à puissance nulle (déplacement, pas de gravure)
        g1_segments = {}  # (label, color) -> ([xs], [ys]) avec NaN en séparateur
        seen_order = []   # ordre d'apparition, pour une légende stable
        raster_strokes_by_key = {}  # (label,color) -> [(x1,y1,x2,y2,S), ...]
        layer_mode_by_key = {}  # (label,color) -> mode de calque / matrice / image
        cx, cy = 0.0, 0.0
        last_modal_g = None
        last_modal_s = None

        token_re = re.compile(r'([A-Za-z])\s*(-?\d*\.?\d+)')

        # Suivi de la gravure en temps réel : chaque trait gravé est relié au numéro de sa ligne
        # dans l'envoi, numérotée comme GCodeStreamerThread (lignes non vides, hors commentaires).
        burn_line_idx = []
        burn_segments = []
        stream_count = 0

        for line in gcode_text.split('\n'):
            raw_line = line.strip()
            if not raw_line:
                continue
            line_idx = None
            if not line.startswith(';'):
                line_idx = stream_count
                stream_count += 1

            try:
                if raw_line.startswith(';'):
                    if 'PHASE 1' in raw_line and 'GRAVURE IMAGE' in raw_line:
                        current_label, current_color = RASTER_LABEL, "#ffaa00"
                        current_layer_mode = "Gravure Remplie"
                        current_is_test_matrix = False
                    elif 'PHASE 2' in raw_line and 'DÉCOUPE VECTORIELLE SVG' in raw_line:
                        current_label, current_color = tr("gen.legend_svg_cut"), DEFAULT_SVG_COLOR
                        current_layer_mode = "Découpe"
                        current_is_test_matrix = False
                    elif raw_line.startswith('; --- MATRICE DE TEST LASER'):
                        current_label = tr("gen.legend_test_matrix")
                        current_color = "#00ff88"
                        current_layer_mode = "Matrice"
                        current_is_test_matrix = True
                    elif raw_line.startswith('; --- CALQUE'):
                        m = re.match(r"; --- CALQUE '(.+)' \[(.+)\] ---", raw_line)
                        if m:
                            layer_name = m.group(1)
                            layer_mode = m.group(2)
                            layer = next((l for l in self.layer_manager.layers if l.name == layer_name), None)
                            current_label = tr("gen.legend_layer").format(name=layer_name)
                            current_color = layer.color if layer else DEFAULT_LAYER_COLOR
                            current_layer_mode = layer_mode
                            current_is_test_matrix = False
                    continue

                is_overscan = 'OVERSCAN_' in raw_line.upper()
                code_part = raw_line.split(';')[0].strip()
                if not code_part:
                    continue

                tokens = token_re.findall(code_part)
                if not tokens:
                    continue

                nx, ny, g_word, s_word, m_word = cx, cy, None, None, None
                for letter, value in tokens:
                    L = letter.upper()
                    try:
                        if L == 'G':
                            g_word = int(float(value))
                        elif L == 'M':
                            m_word = int(float(value))
                        elif L == 'X':
                            nx = float(value)
                        elif L == 'Y':
                            ny = float(value)
                        elif L == 'S':
                            s_word = float(value)
                    except ValueError:
                        pass

                if g_word is not None:
                    last_modal_g = g_word
                cmd_g = g_word if g_word is not None else last_modal_g

                if s_word is not None:
                    last_modal_s = s_word
                elif m_word == 5:
                    last_modal_s = 0.0

                if is_overscan:
                    ov_x.extend([cx, nx, float('nan')])
                    ov_y.extend([cy, ny, float('nan')])
                elif cmd_g == 0:
                    g0_x.extend([cx, nx, float('nan')])
                    g0_y.extend([cy, ny, float('nan')])
                elif cmd_g == 1:
                    key = (current_label, current_color)
                    has_power = last_modal_s is not None and last_modal_s > 0

                    if has_power:
                        # Gravure réelle : comptée pour la légende et
                        # affichée dans la couleur du calque/label.
                        if key not in g1_segments:
                            g1_segments[key] = ([], [])
                            seen_order.append(key)
                            layer_mode_by_key[key] = current_layer_mode
                        xs, ys = g1_segments[key]
                        xs.extend([cx, nx, float('nan')])
                        ys.extend([cy, ny, float('nan')])
                        raster_strokes_by_key.setdefault(key, []).append((cx, cy, nx, ny, last_modal_s))
                        if line_idx is not None:
                            burn_line_idx.append(line_idx)
                            burn_segments.append((cx, cy, nx, ny))
                    else:
                        # G1 à puissance nulle (laser éteint / M5) : un vrai
                        # déplacement, jamais de la gravure. Affiché comme un
                        # G0 (gris pointillé), pour ne jamais se confondre
                        # avec un tracé réellement gravé de la même couleur —
                        # sinon, entre deux motifs séparés par un déplacement
                        # G1 à vide (ex: les carrés d'une matrice de test),
                        # l'écart entre les motifs apparaît à tort dans la
                        # couleur de la gravure, rendant impossible de
                        # distinguer visuellement gravure et non-gravure.
                        g1_travel_x.extend([cx, nx, float('nan')])
                        g1_travel_y.extend([cy, ny, float('nan')])

                cx, cy = nx, ny
            except Exception:
                # Une ligne isolée mal formée ne doit jamais faire échouer tout
                # l'aperçu : on l'ignore et on continue avec les suivantes.
                continue

        # Décision du mode d'affichage.
        #
        # - Gravure Image interne       -> toujours raster
        # - Calque "Gravure Remplie"    -> raster
        # - G-Code importé non identifié -> heuristique raster
        # - SVG en découpe              -> vectoriel
        # - Matrice de test (Gravure)   -> raster, comme la gravure image
        # - Matrice de test (Découpe)   -> vectoriel
        # - Découpe / Marquage contour  -> vectoriel
        raster_groups = {}
        raster_keys_rendered_as_image = set()

        for key, strokes in raster_strokes_by_key.items():
            label, _color = key
            layer_mode = layer_mode_by_key.get(key)

            if label == RASTER_LABEL:
                # Image générée par l'application.
                is_raster = True

            elif label == MATRIX_LABEL:
                # Matrice de test en mode Gravure : rendu tramé en niveaux de gris, comme
                # une gravure image (chaque case, y compris celles avec une partie d'image,
                # reste lisible). En mode Découpe (ou matrice d'origine inconnue, ex. G-Code
                # rechargé), on garde l'affichage vectoriel.
                matrix_params = getattr(self, "last_test_matrix_params", None) or {}
                is_raster = matrix_params.get("mode") == "Gravure"

            elif label == tr("gen.legend_svg_cut"):
                # Un SVG de découpe doit rester affiché comme des contours.
                is_raster = False

            elif layer_mode == "Découpe":
                # Contour vectoriel : jamais de reconstruction raster.
                is_raster = False

            elif layer_mode == "Marquage (Contour)":
                # Contour vectoriel : jamais de reconstruction raster.
                is_raster = False

            elif layer_mode == "Gravure Remplie":
                # Remplissage vectoriel par balayage.
                is_raster = True

            elif label == UNKNOWN_LABEL:
                # G-Code importé depuis LaserGRBL ou un autre logiciel.
                # Il n'a généralement aucun marqueur de phase : on utilise
                # l'ancienne heuristique uniquement dans ce cas.
                row_keys = {
                    round((y1 + y2) / 4.0, 4)
                    for (_, y1, _, y2, _) in strokes
                }
                n_rows = len(row_keys)
                avg_segs_per_row = (
                    len(strokes) / n_rows
                    if n_rows
                    else 0
                )

                is_raster = (
                    n_rows >= 2
                    and len(strokes) >= 40
                    and avg_segs_per_row >= 4.0
                )

            else:
                # Par sécurité, tout groupe identifié mais non reconnu
                # reste vectoriel afin d'éviter une fausse image.
                is_raster = False

            if is_raster:
                raster_groups[key] = strokes
                raster_keys_rendered_as_image.add(key)

        legend_rows = (
            f'<div><span style="color:#888888">■</span> {tr("gen.legend_g0").format(n=len(g0_x)//3)}</div>'
            f'<div><span style="color:#ff3355">■</span> {tr("gen.legend_overscan").format(n=len(ov_x)//3)}</div>'
            f'<div><span style="color:{BURN_COLOR}">■</span> {tr("gen.legend_burned")}</div>'
        )
        if g1_travel_x:
            legend_rows += f'<div><span style="color:#888888">■</span> {tr("gen.legend_g1_travel").format(n=len(g1_travel_x)//3)}</div>'
        # Pastille de légende = couleur réellement affichée. La gravure image
        # n'est jamais teintée (tint=None) : elle est dessinée en noir sur le
        # matériau clair, ou en blanc sur noir si l'aperçu négatif est coché.
        # La couleur interne de la phase (orange) ne sert qu'au regroupement.
        negative_preview = bool(getattr(self, "chk_negative_raster_preview", None)
                                and self.chk_negative_raster_preview.isChecked())
        if negative_preview:
            raster_swatch = '<span style="color:#ffffff; background-color:#000000">■</span>'
        else:
            material_hex = "#%02x%02x%02x" % PREVIEW_MATERIAL_RGB
            raster_swatch = f'<span style="color:#000000; background-color:{material_hex}">■</span>'

        for label, color in seen_order:
            xs, ys = g1_segments[(label, color)]
            n_segs = len(xs) // 3
            if (label, color) in raster_keys_rendered_as_image:
                swatch = raster_swatch if label in (RASTER_LABEL, MATRIX_LABEL) else f'<span style="color:{color}">■</span>'
                legend_rows += f'<div>{swatch} {tr("gen.legend_layer_raster_note").format(label=label, n=n_segs)}</div>'
            else:
                legend_rows += f'<div><span style="color:{color}">■</span> {tr("gen.legend_layer_segments").format(label=label, n=n_segs)}</div>'

        self.info_text_item = pg.TextItem(
            html=f'<div style="color: #ffffff; background-color: rgba(0,0,0,170); padding: 4px;">{legend_rows}</div>',
            anchor=(0, 0)
        )
        self.plot_widget.addItem(self.info_text_item)
        # Le clear() ci-dessus a aussi retiré le point rouge de position de la tête (DRO) : on le
        # remet, sans qu'il compte dans le cadrage automatique de la vue (ignoreBounds).
        if hasattr(self, "gcode_position_marker"):
            self.plot_widget.addItem(self.gcode_position_marker, ignoreBounds=True)
        self._setup_burn_overlay(burn_line_idx, burn_segments)

        # Reconstruction raster par calque seulement si cela correspond à une vraie image.
        for key, strokes in raster_groups.items():
            label, color = key
            # Image et matrice de test : jamais teintées (gris sur matériau clair, ou négatif).
            tint = None if label in (RASTER_LABEL, MATRIX_LABEL) else color
            # Matrice de test : les niveaux de puissance sont relevés (gamma 0,5) pour que
            # l'image de chaque case reste visible, y compris celles à faible puissance.
            gamma = 0.5 if label == MATRIX_LABEL else 1.0
            self._plot_raster_reconstruction(strokes, tint_color=tint, gamma=gamma)

        hide_rapid_moves = getattr(self, "chk_hide_rapid_moves", None)
        hide_rapid = bool(
            hide_rapid_moves and hide_rapid_moves.isChecked()
        )

        if g0_x and not hide_rapid:
            self.plot_widget.plot(
                g0_x,
                g0_y,
                pen=pg.mkPen(
                    color="#555555",
                    width=1,
                    style=Qt.PenStyle.DotLine
                ),
                connect="finite"
            )

        if g1_travel_x and not hide_rapid:
            # G1 à puissance nulle : un déplacement, pas de la gravure — même
            # style que le G0 rapide pour qu'il soit clair qu'il ne s'agit
            # pas d'un tracé gravé, malgré le G1 (voir le commentaire à
            # l'enregistrement, plus haut dans cette fonction).
            self.plot_widget.plot(
                g1_travel_x,
                g1_travel_y,
                pen=pg.mkPen(
                    color="#555555",
                    width=1,
                    style=Qt.PenStyle.DotLine
                ),
                connect="finite"
            )

        if ov_x:
            # Sur une matrice de test tramée, des centaines de lignes de surbalayage se
            # superposent en barres rouges pleines qui cachent les bords des cases :
            # on les affiche plus fines et translucides pour garder l'image lisible.
            matrix_as_image = any(k[0] == MATRIX_LABEL for k in raster_keys_rendered_as_image)
            ov_pen = (
                pg.mkPen(color=(255, 51, 85, 80), width=1, style=Qt.PenStyle.DashLine)
                if matrix_as_image
                else pg.mkPen(color="#ff3355", width=2, style=Qt.PenStyle.DashLine)
            )
            self.plot_widget.plot(
                ov_x,
                ov_y,
                pen=ov_pen,
                connect="finite"
            )

        for (label, color), (xs, ys) in g1_segments.items():
            if (label, color) in raster_keys_rendered_as_image:
                continue
            self.plot_widget.plot(
                xs,
                ys,
                pen=pg.mkPen(color=color, width=1.8),
                connect="finite"
            )

        self.plot_widget.enableAutoRange()
        self.plot_widget.autoRange()
