"""Onglet « Calques » (LayersTab) : relais du signal et accès aux calques."""
import os
import sys
import unittest

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.join(REPO, "src", "laser_studio")
sys.path.insert(0, os.path.dirname(ROOT))

try:
    from PyQt6.QtWidgets import QApplication, QLineEdit
    from laser_studio.ui.tabs.layers import LayersTab
    from laser_studio.vector_layers import LayerManager
except ImportError:  # PyQt6 manquant
    LayersTab = None


@unittest.skipIf(LayersTab is None, "PyQt6 non importable ici")
class LayersTabTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def make(self):
        manager = LayerManager()
        tab = LayersTab(manager, focal_getter=lambda: 0.1)
        self.addCleanup(tab.deleteLater)
        return tab, manager

    def test_editing_a_layer_emits_layers_changed(self):
        tab, manager = self.make()
        manager.add_layer()                            # calque ajouté : nom modifiable
        tab.refresh()
        received = []
        tab.layers_changed.connect(lambda: received.append(manager.layers[3].name))
        edit = tab.layer_widget.table.cellWidget(3, 1)
        edit.setText("Mon calque")
        edit.textEdited.emit("Mon calque")
        edit.editingFinished.emit()
        self.assertIn("Mon calque", received)

    def test_focal_getter_is_shared_with_the_layer_list(self):
        tab, _ = self.make()
        self.assertEqual(tab.focal_getter(), 0.1)
        self.assertIs(tab.layer_widget.focal_getter, tab.focal_getter)

    def test_refresh_follows_the_layer_manager(self):
        tab, manager = self.make()
        count = len(tab.layer_widget.findChildren(QLineEdit))
        manager.add_layer()
        tab.refresh()
        self.app.processEvents()
        self.assertGreater(len(tab.layer_widget.findChildren(QLineEdit)), count)


if __name__ == "__main__":
    unittest.main()
