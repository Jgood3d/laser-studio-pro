# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules

hiddenimports = ['serial', 'PyQt6.QtWebEngineWidgets', 'PyQt6.QtWebEngineCore', 'laser_studio.i18n', 'laser_studio.i18n.language', 'laser_studio.i18n.translations', 'laser_studio.vector.puzzle_generator', 'laser_studio.vector.box_generator', 'laser_studio.vector.importers', 'laser_studio.ui.dialogs.puzzle', 'laser_studio.ui.dialogs.puzzle.dialog', 'laser_studio.ui.dialogs.box_generator', 'laser_studio.ui.dialogs.nesting', 'stencil_studio.studio_dialog', 'stencil_studio.studio_window', 'stencil_studio.studio', 'stencil_studio.core', 'stencil_studio.engrave', 'stencil_studio.lightbox', 'stencil_studio.lsp_bridge', 'stencil_studio.subject_ai', 'stencil_studio.i18n', 'scipy.spatial', 'scipy.ndimage']
hiddenimports += collect_submodules('serial')


a = Analysis(
    ['main.py'],
    pathex=['src'],
    binaries=[],
    datas=[('src/laser_studio/resources/laser_studio_pro_banner.png', 'resources'), ('src/laser_studio/resources/laser_studio_pro_512.png', 'resources'), ('src/laser_studio/resources/buy_me_a_coffee.png', 'resources'), ('src/laser_studio/resources/icons', 'resources/icons'), ('stencil_studio', 'stencil_studio')],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='LaserStudioPro',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['src/laser_studio/resources/laser_studio_pro.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='LaserStudioPro',
)
