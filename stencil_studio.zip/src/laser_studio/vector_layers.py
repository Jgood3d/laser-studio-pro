# -*- coding: utf-8 -*-
"""
vector_layers.py — Extension "Calques + Texte/Formes" pour Laser Studio Pro
============================================================================

Ce module est 100% additif : il ne modifie ni ne remplace le pipeline
existant (image tramée + découpe SVG). Il ajoute :

  1) LaserLayer / LayerManager / LayerManagerWidget
     -> Calques façon LightBurn : couleur, mode (Découpe / Gravure Remplie /
        Marquage), puissance, vitesse, passes, activé/désactivé.

  2) VectorObject (TextObject / ShapeObject) + VectorCanvasView
     -> Un éditeur vectoriel (QGraphicsScene en mm) où l'on place du texte
        (n'importe quelle police installée, miroir H/V, orientation
        horizontale/verticale) et des formes (rectangle, ellipse, ligne,
        polygone régulier), chaque objet étant rattaché à un calque.

  3) extract_vector_layer_data() / build_vector_layers_gcode()
     -> Conversion des objets vectoriels en données géométriques "pures"
        (listes de points, thread-safe) puis en G-Code, calque par calque,
        avec la même convention de coordonnées que le reste de l'appli
        (Y inversé, origine bas-gauche ou centre).

Toute la géométrie lourde (aplatissement des courbes de Bézier, remplissage
par balayage de lignes) est faite une seule fois lors de la génération du
job, dans le thread de calcul existant (AdvancedGCodeWorker) : aucune perte
de fluidité de l'interface.
"""

import math
import re
import time
import uuid

from svg.path import parse_path, Move, Line, Close, CubicBezier, QuadraticBezier, Arc

from PyQt6.QtCore import Qt, QRectF, QPointF, QTimer, pyqtSignal
from PyQt6.QtGui import (QColor, QFont, QFontMetricsF, QPainterPath, QPen,
                          QBrush, QTransform, QPolygonF, QPainter, QKeySequence)
from PyQt6.QtWidgets import (
    QGraphicsView, QGraphicsScene, QGraphicsPathItem, QGraphicsItem,
    QGraphicsRectItem, QGraphicsEllipseItem, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout,
    QPushButton, QLabel, QTableWidget, QHeaderView,
    QColorDialog, QComboBox, QDoubleSpinBox, QSpinBox, QCheckBox, QDialog,
    QDialogButtonBox, QLineEdit, QFontComboBox, QRadioButton, QButtonGroup,
    QMessageBox, QAbstractItemView, QToolButton, QMenu, QInputDialog
)

from laser_studio.i18n import tr
from laser_studio.vector.order import CUT_MODE, order_layers_for_cutting, order_polygons_inner_first
from laser_studio.vector.nudge import NUDGE_UNDO_WINDOW_S, nudge_step


# ============================================================================
# 1) CALQUES (LAYERS)
# ============================================================================

LAYER_MODES = ["Gravure Remplie", "Découpe", "Marquage (Contour)"]
# Les valeurs de LAYER_MODES sont des identifiants internes (sauvegardés dans
# les projets, testés dans le générateur de G-Code) : elles ne changent jamais.
# Seul leur AFFICHAGE est traduit, via ces clés.
LAYER_MODE_TR_KEYS = {
    "Découpe": "layers.mode.cut",
    "Gravure Remplie": "layers.mode.fill",
    "Marquage (Contour)": "layers.mode.mark",
}

DEFAULT_LAYER_COLORS = [
    "#ff3b30", "#34c759", "#0a84ff", "#ff9f0a",
    "#bf5af2", "#64d2ff", "#ffd60a", "#ff375f",
]


class LaserLayer:
    """Un calque = une couleur + un jeu de réglages laser, comme dans LightBurn."""

    def __init__(self, name="Calque", color="#ff3b30", mode="Découpe",
                 power=80.0, speed=300, passes=1, line_interval=0.10,
                 enabled=True, layer_id=None, line_interval_linked=False):
        self.id = layer_id or uuid.uuid4().hex[:8]
        self.name = name
        self.color = color
        self.mode = mode                    # cf. LAYER_MODES
        self.power = float(power)           # %
        self.speed = int(speed)             # mm/min
        self.passes = int(passes)
        self.line_interval = float(line_interval)  # mm (pas du remplissage)
        # Si True, line_interval suit automatiquement la taille du spot
        # (spin_machine_focal) à chaque changement — voir LayerManagerWidget.
        self.line_interval_linked = bool(line_interval_linked)
        self.enabled = bool(enabled)

    def to_dict(self):
        return dict(self.__dict__)

    @staticmethod
    def from_dict(d):
        layer = LaserLayer()
        layer.__dict__.update(d)
        return layer


class LayerManager:
    """Conteneur ordonné de LaserLayer, avec un signal Qt-free (callbacks simples)."""

    def __init__(self):
        # Gravure en première position : calque proposé par défaut pour la
        # gravure des images (tramage / séparation couleur).
        self.layers = [
            LaserLayer(name=tr("layers.default_name_engrave_text"), color=DEFAULT_LAYER_COLORS[2],
                       mode="Gravure Remplie", power=35, speed=2000, passes=1),
            LaserLayer(name=tr("layers.default_name_cut"), color=DEFAULT_LAYER_COLORS[0],
                       mode="Découpe", power=90, speed=250, passes=2),
        ]

    def add_layer(self, line_interval=None, line_interval_linked=False):
        idx = len(self.layers)
        color = DEFAULT_LAYER_COLORS[idx % len(DEFAULT_LAYER_COLORS)]
        kwargs = {"line_interval_linked": line_interval_linked}
        if line_interval is not None:
            kwargs["line_interval"] = line_interval
        layer = LaserLayer(name=f"Calque {idx + 1}", color=color, **kwargs)
        self.layers.append(layer)
        return layer

    def remove_layer(self, layer_id):
        self.layers = [l for l in self.layers if l.id != layer_id]

    def move_layer(self, layer_id, delta):
        """Décale un calque de `delta` positions dans la liste (-1 = monter,
        +1 = descendre). L'ordre de la liste est aussi l'ordre d'exécution
        des calques dans le G-Code. Renvoie le nouvel index, ou None si le
        calque est introuvable / déjà en butée."""
        idx = next((i for i, l in enumerate(self.layers) if l.id == layer_id), None)
        if idx is None:
            return None
        new_idx = idx + delta
        if new_idx < 0 or new_idx >= len(self.layers):
            return None
        self.layers.insert(new_idx, self.layers.pop(idx))
        return new_idx

    def get(self, layer_id):
        for l in self.layers:
            if l.id == layer_id:
                return l
        return None

    def default_svg_layer(self):
        """Calque par défaut des imports SVG (import classique et PNG -> SVG) :
        le premier calque en mode Découpe. À défaut, le premier calque."""
        for l in self.layers:
            if l.mode == "Découpe":
                return l
        return self.layers[0] if self.layers else None

    def to_list(self):
        return [l.to_dict() for l in self.layers]

    def load_list(self, data):
        self.layers = [LaserLayer.from_dict(d) for d in data] if data else []


class LayerManagerWidget(QWidget):
    """Table façon LightBurn : Couleur | Nom | Mode | Puissance | Vitesse | Passes | Actif"""

    layers_changed = pyqtSignal()

    COLUMN_KEYS = ["layers.col.color", "layers.col.name", "layers.col.mode",
                   "layers.col.power", "layers.col.speed", "layers.col.passes",
                   "layers.col.fill_step", "layers.col.active"]

    def __init__(self, layer_manager: LayerManager, parent=None, focal_getter=None):
        super().__init__(parent)
        self.mgr = layer_manager
        # Callable optionnel (ex. lambda: self.spin_machine_focal.value())
        # renvoyant la taille du spot laser (mm) réglée dans Paramètres
        # Machine — même logique de lien que l'onglet Image & Filtres
        # (mode "Focale laser" pour l'intervalle de lignes du tramage).
        self.focal_getter = focal_getter
        self._fill_spins = []  # [(spin_fill, layer), ...] pour refresh_focal_quality()

        self.COLUMNS = [tr(k) for k in self.COLUMN_KEYS]

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        btn_row = QHBoxLayout()
        btn_add = QPushButton(tr("layers.add"))
        btn_add.clicked.connect(self.on_add)
        btn_del = QPushButton(tr("layers.remove"))
        btn_del.clicked.connect(self.on_remove)
        btn_up = QPushButton(tr("layers.move_up"))
        btn_up.setToolTip(tr("layers.move_up_tip"))
        btn_up.clicked.connect(lambda: self.on_move(-1))
        btn_down = QPushButton(tr("layers.move_down"))
        btn_down.setToolTip(tr("layers.move_down_tip"))
        btn_down.clicked.connect(lambda: self.on_move(1))
        btn_row.addWidget(btn_add)
        btn_row.addWidget(btn_del)
        btn_row.addWidget(btn_up)
        btn_row.addWidget(btn_down)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        layout.addWidget(self.table)

        self.refresh()

    # -- construction des lignes -------------------------------------------------
    def refresh(self):
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        self._fill_spins = []
        for layer in self.mgr.layers:
            self._add_row(layer)
        self.table.blockSignals(False)

    def _add_row(self, layer: LaserLayer):
        row = self.table.rowCount()
        self.table.insertRow(row)

        # Couleur (bouton pastille)
        btn_color = QToolButton()
        btn_color.setStyleSheet(f"background-color:{layer.color}; border:1px solid #222;")
        btn_color.setFixedSize(28, 22)
        btn_color.clicked.connect(lambda _, l=layer, b=btn_color: self._pick_color(l, b))
        self.table.setCellWidget(row, 0, btn_color)

        name_edit = QLineEdit(layer.name)
        name_edit.textChanged.connect(lambda t, l=layer: self._set(l, "name", t))
        self.table.setCellWidget(row, 1, name_edit)

        combo_mode = QComboBox()
        for mode_id in LAYER_MODES:
            combo_mode.addItem(tr(LAYER_MODE_TR_KEYS[mode_id]), mode_id)
        idx_mode = combo_mode.findData(layer.mode)
        if idx_mode >= 0:
            combo_mode.setCurrentIndex(idx_mode)
        combo_mode.currentIndexChanged.connect(
            lambda i, l=layer, c=combo_mode: self._set(l, "mode", c.itemData(i))
        )
        self.table.setCellWidget(row, 2, combo_mode)

        spin_power = QDoubleSpinBox(); spin_power.setRange(0, 100); spin_power.setValue(layer.power)
        spin_power.valueChanged.connect(lambda v, l=layer: self._set(l, "power", v))
        self.table.setCellWidget(row, 3, spin_power)

        spin_speed = QSpinBox(); spin_speed.setRange(1, 20000); spin_speed.setValue(layer.speed)
        spin_speed.valueChanged.connect(lambda v, l=layer: self._set(l, "speed", v))
        self.table.setCellWidget(row, 4, spin_speed)

        spin_passes = QSpinBox(); spin_passes.setRange(1, 50); spin_passes.setValue(layer.passes)
        spin_passes.valueChanged.connect(lambda v, l=layer: self._set(l, "passes", v))
        self.table.setCellWidget(row, 5, spin_passes)

        fill_cell = QWidget()
        fill_layout = QHBoxLayout(fill_cell)
        fill_layout.setContentsMargins(2, 0, 2, 0)
        fill_layout.setSpacing(2)

        spin_fill = QDoubleSpinBox(); spin_fill.setRange(0.02, 5.0); spin_fill.setSingleStep(0.02)
        spin_fill.setDecimals(2); spin_fill.setValue(layer.line_interval)
        spin_fill.valueChanged.connect(lambda v, l=layer: self._set(l, "line_interval", v))
        spin_fill.valueChanged.connect(lambda _v, s=spin_fill: self._update_fill_quality(s))
        fill_layout.addWidget(spin_fill)

        btn_focal = QToolButton()
        btn_focal.setCheckable(True)
        btn_focal.setChecked(layer.line_interval_linked)
        btn_focal.setFixedSize(24, 22)
        btn_focal.setEnabled(self.focal_getter is not None)
        self._style_link_button(btn_focal, layer.line_interval_linked)
        btn_focal.toggled.connect(
            lambda checked, l=layer, s=spin_fill, b=btn_focal: self._on_link_toggled(checked, l, s, b)
        )
        fill_layout.addWidget(btn_focal)
        spin_fill.setEnabled(not layer.line_interval_linked)

        self.table.setCellWidget(row, 6, fill_cell)
        self._fill_spins.append((spin_fill, layer))
        self._update_fill_quality(spin_fill)

        chk_enabled = QCheckBox(); chk_enabled.setChecked(layer.enabled)
        chk_enabled.stateChanged.connect(lambda v, l=layer: self._set(l, "enabled", bool(v)))
        self.table.setCellWidget(row, 7, chk_enabled)

        self.table.setRowHeight(row, 30)
        self.table.setProperty(f"row_layer_{row}", layer.id)

    def _pick_color(self, layer, button):
        color = QColorDialog.getColor(QColor(layer.color), self, tr("layers.color_dialog_title"))
        if color.isValid():
            layer.color = color.name()
            button.setStyleSheet(f"background-color:{layer.color}; border:1px solid #222;")
            self.layers_changed.emit()

    def _set(self, layer, attr, value):
        setattr(layer, attr, value)
        self.layers_changed.emit()

    def _apply_focal_to_fill(self, spin_fill):
        """Cale le pas de remplissage sur la taille du spot laser configurée
        dans Paramètres Machine (même principe que le mode 'Focale laser' de
        l'onglet Image & Filtres)."""
        if self.focal_getter is None:
            return
        focal = self.focal_getter()
        if focal and focal > 0:
            spin_fill.setValue(max(spin_fill.minimum(), min(spin_fill.maximum(), focal)))

    def _style_link_button(self, button, linked):
        if linked:
            button.setText("🔗")
            button.setToolTip(tr("layers.link_tip_linked"))
            button.setStyleSheet("background-color:#2f6f4f;")
        else:
            button.setText("🎯")
            button.setToolTip(tr("layers.link_tip_unlinked"))
            button.setStyleSheet("")

    def _on_link_toggled(self, checked, layer, spin_fill, button):
        layer.line_interval_linked = checked
        spin_fill.setEnabled(not checked)
        self._style_link_button(button, checked)
        if checked:
            self._apply_focal_to_fill(spin_fill)  # déclenche aussi _set + pastille
        else:
            self.layers_changed.emit()

    def _update_fill_quality(self, spin_fill):
        """Colore la bordure du champ selon l'adéquation du pas choisi avec
        la taille du spot laser — mêmes seuils que la pastille de qualité de
        l'onglet Image & Filtres (ratio pas/focale)."""
        if self.focal_getter is None:
            spin_fill.setStyleSheet("")
            return
        focal = self.focal_getter()
        if not focal or focal <= 0:
            spin_fill.setStyleSheet("")
            return
        ratio = spin_fill.value() / focal
        if ratio < 0.6:
            color = "#e05656"      # trop fin
        elif ratio < 0.9:
            color = "#e0a656"      # fin
        elif ratio <= 2.25:
            color = "#56c271"      # correct / recommandé
        else:
            color = "#999999"      # grossier mais correct
        spin_fill.setStyleSheet(f"border: 1px solid {color};")

    def refresh_focal_quality(self):
        """À appeler quand la taille du spot change dans Paramètres Machine.
        Les calques 'liés' voient leur pas remplissage recalculé
        automatiquement ; les autres n'ont que leur pastille de qualité
        rafraîchie."""
        for spin_fill, layer in self._fill_spins:
            if layer.line_interval_linked:
                self._apply_focal_to_fill(spin_fill)
            else:
                self._update_fill_quality(spin_fill)

    def link_all_to_focal(self):
        """Lie tous les calques à la taille du spot en une fois ET applique
        immédiatement la valeur de la focale à chacun — appelé
        automatiquement au démarrage et à la validation des Paramètres
        Machine, pour éviter d'avoir à cocher le 🔗 sur chaque calque un par
        un. Avant, seul le drapeau 'lié' était posé (icône verte) sans
        jamais recalculer line_interval : un calque encore à sa valeur par
        défaut (0.10 mm, celle de LaserLayer) restait affiché tel quel,
        avec un lien vert trompeur ne correspondant pas à la focale réelle."""
        if self.focal_getter is None:
            return
        focal = self.focal_getter()
        for layer in self.mgr.layers:
            layer.line_interval_linked = True
            if focal and focal > 0:
                layer.line_interval = focal
        self.refresh()
        self.layers_changed.emit()

    def on_add(self):
        linked = self.focal_getter is not None
        default_interval = self.focal_getter() if linked else None
        self.mgr.add_layer(line_interval=default_interval, line_interval_linked=linked)
        self.refresh()
        self.layers_changed.emit()

    def on_remove(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.mgr.layers):
            return
        layer = self.mgr.layers[row]
        self.mgr.remove_layer(layer.id)
        self.refresh()
        self.layers_changed.emit()

    def on_move(self, delta):
        """Monte (-1) ou descend (+1) le calque sélectionné, puis garde la
        ligne déplacée sélectionnée pour pouvoir enchaîner les clics."""
        row = self.table.currentRow()
        if row < 0 or row >= len(self.mgr.layers):
            return
        new_row = self.mgr.move_layer(self.mgr.layers[row].id, delta)
        if new_row is None:
            return
        self.refresh()
        self.table.setCurrentCell(new_row, 1)
        self.table.selectRow(new_row)
        self.layers_changed.emit()

    def current_layer_id(self):
        row = self.table.currentRow()
        if 0 <= row < len(self.mgr.layers):
            return self.mgr.layers[row].id
        return self.mgr.layers[0].id if self.mgr.layers else None


# ============================================================================
# 2) OBJETS VECTORIELS (TEXTE / FORMES)
# ============================================================================

class VectorObject:
    """Classe de base : position (mm), rotation, miroirs, calque associé.
    Le repère utilisé est identique à celui du SVG existant dans l'appli :
    origine en haut-gauche de la zone de travail, Y croissant vers le bas.
    """
    kind = "generic"

    def __init__(self, x_mm=10.0, y_mm=10.0, rotation_deg=0.0,
                 mirror_h=False, mirror_v=False, layer_id=None, obj_id=None):
        self.id = obj_id or uuid.uuid4().hex[:8]
        self.x_mm = x_mm
        self.y_mm = y_mm
        self.rotation_deg = rotation_deg
        self.mirror_h = mirror_h
        self.mirror_v = mirror_v
        self.layer_id = layer_id

    def local_path(self) -> QPainterPath:
        """Doit renvoyer un QPainterPath en mm, centré sur l'origine locale (0,0)."""
        raise NotImplementedError

    def world_transform(self) -> QTransform:
        """Repère 'monde' = origine en BAS-GAUCHE de la zone de travail, Y croissant
        vers le HAUT (comme le repère machine / GRBL), directement exploitable pour
        le G-Code sans inversion supplémentaire. Les tracés locaux (police de
        caractères, formes) sont eux nativement en Y descendant (convention Qt) :
        on applique donc par défaut une inversion verticale (sy=-1) pour les faire
        correspondre au repère monde Y-haut, ce qui replace aussi correctement
        l'ancre du texte (le haut du texte reste 'en haut'). Cocher 'Miroir
        Vertical' annule cette inversion, produisant un miroir par rapport au
        rendu normal, comme attendu.
        """
        t = QTransform()
        t.translate(self.x_mm, self.y_mm)
        t.rotate(self.rotation_deg)
        sx = -1.0 if self.mirror_h else 1.0
        sy = 1.0 if self.mirror_v else -1.0
        t.scale(sx, sy)
        return t

    def world_path(self) -> QPainterPath:
        return self.world_transform().map(self.local_path())

    def to_dict(self):
        d = dict(self.__dict__)
        d["kind"] = self.kind
        return d

    @staticmethod
    def from_dict(d):
        kind = d.get("kind")
        if kind == "text":
            obj = TextObject.__new__(TextObject)
            obj.__dict__.update({k: v for k, v in d.items() if k != "kind"})
        elif kind == "shape":
            obj = ShapeObject.__new__(ShapeObject)
            obj.__dict__.update({k: v for k, v in d.items() if k != "kind"})
        elif kind == "svg_path":
            obj = SvgPathObject.from_dict(d)
        else:
            raise ValueError(f"Type d'objet vectoriel inconnu : {kind}")
        return obj


class TextObject(VectorObject):
    """Texte vectoriel basé sur une vraie police système (contours réels, pas de
    police 5x7). Prend en charge miroir H/V et orientation horizontale/verticale."""
    kind = "text"
    _REF_PT = 200.0  # taille de référence (grande) pour un rendu de courbes précis

    def __init__(self, text="TEXTE", font_family="Arial", size_mm=10.0,
                 bold=False, italic=False, vertical=False,
                 letter_spacing_mm=0.0, **kwargs):
        super().__init__(**kwargs)
        self.text = text
        self.font_family = font_family
        self.size_mm = size_mm
        self.bold = bold
        self.italic = italic
        self.vertical = vertical
        self.letter_spacing_mm = letter_spacing_mm

    def _font(self):
        font = QFont(self.font_family)
        font.setPointSizeF(self._REF_PT)
        font.setBold(self.bold)
        font.setItalic(self.italic)
        return font

    def local_path(self) -> QPainterPath:
        font = self._font()
        metrics = QFontMetricsF(font)
        ref_height = metrics.ascent() if metrics.ascent() > 0 else self._REF_PT
        scale = self.size_mm / ref_height

        raw_path = QPainterPath()
        if not self.vertical:
            raw_path.addText(0, 0, font, self.text)
            if self.letter_spacing_mm:
                # Espacement additionnel : reconstruit lettre par lettre
                raw_path = QPainterPath()
                cursor_x = 0.0
                extra_advance = self.letter_spacing_mm / max(scale, 1e-6)
                for ch in self.text:
                    p = QPainterPath()
                    p.addText(cursor_x, 0, font, ch)
                    raw_path.addPath(p)
                    cursor_x += metrics.horizontalAdvance(ch) + extra_advance
        else:
            # Orientation verticale : une lettre sous l'autre
            line_height = metrics.ascent() + metrics.descent()
            extra = self.letter_spacing_mm / max(scale, 1e-6)
            cursor_y = 0.0
            for ch in self.text:
                if ch == " ":
                    cursor_y += line_height + extra
                    continue
                p = QPainterPath()
                p.addText(0, cursor_y, font, ch)
                raw_path.addPath(p)
                cursor_y += line_height + extra

        # Réancre l'origine locale (0,0) sur le coin BAS-GAUCHE du texte
        # (cohérent avec les formes et le repère machine bas-gauche/Y-haut) :
        # X/Y désignent le coin bas-gauche du bloc de texte, pas son centre.
        bbox = raw_path.boundingRect()
        reanchor = QTransform()
        reanchor.translate(-bbox.left(), -bbox.bottom())
        path = reanchor.map(raw_path)
        return QTransform().scale(scale, scale).map(path)


class ShapeObject(VectorObject):
    """Formes géométriques simples : rectangle, ellipse, ligne, polygone régulier."""
    kind = "shape"
    SHAPE_TYPES = ["Rectangle", "Ellipse", "Ligne", "Polygone Régulier"]

    def __init__(self, shape_type="Rectangle", width_mm=20.0, height_mm=15.0,
                 sides=6, **kwargs):
        super().__init__(**kwargs)
        self.shape_type = shape_type
        self.width_mm = width_mm
        self.height_mm = height_mm
        self.sides = sides  # utilisé pour le polygone régulier

    def local_path(self) -> QPainterPath:
        path = QPainterPath()
        w, h = self.width_mm, self.height_mm
        if self.shape_type == "Rectangle":
            path.addRect(0, 0, w, h)
        elif self.shape_type == "Ellipse":
            path.addEllipse(0, 0, w, h)
        elif self.shape_type == "Ligne":
            path.moveTo(0, 0)
            path.lineTo(w, 0)
        elif self.shape_type == "Polygone Régulier":
            n = max(3, self.sides)
            r = min(w, h) / 2.0
            poly = QPolygonF()
            for i in range(n):
                angle = -math.pi / 2 + (2 * math.pi * i / n)
                poly.append(QPointF(r * math.cos(angle), r * math.sin(angle)))
            path.addPolygon(poly)
            path.closeSubpath()

        # Réancre l'origine locale (0,0) sur le coin BAS-GAUCHE du bounding
        # box de la forme (cohérent avec le repère machine bas-gauche/Y-haut).
        # X/Y désignent ainsi le COIN de la forme, pas son centre — c'est ce
        # qui manquait : avec un centrage, taper X=10 plaçait le CENTRE à
        # 10mm, donc le bord gauche réel à 10 - largeur/2, ce qui donnait
        # l'impression que la position tapée n'était jamais respectée.
        bbox = path.boundingRect()
        reanchor = QTransform()
        reanchor.translate(-bbox.left(), -bbox.bottom())
        return reanchor.map(path)


class SvgPathObject(VectorObject):
    """Objet issu d'un import SVG « dégroupé » : un tracé FIXE (contrairement
    au texte ou aux formes simples, il n'est pas régénéré à partir de
    paramètres — c'est la géométrie exacte extraite du fichier SVG source).
    Redimensionnable via scale_x/scale_y (voir AssignLayerDialog)."""
    kind = "svg_path"

    def __init__(self, local_path_data=None, source_tag="", scale_x=1.0, scale_y=1.0, **kwargs):
        super().__init__(**kwargs)
        self._local_path_data = local_path_data if local_path_data is not None else QPainterPath()
        self.source_tag = source_tag  # ex: "path", "rect"... juste informatif
        self.scale_x = scale_x
        self.scale_y = scale_y

    def local_path(self) -> QPainterPath:
        sx = getattr(self, "scale_x", 1.0)
        sy = getattr(self, "scale_y", 1.0)
        if sx == 1.0 and sy == 1.0:
            return QPainterPath(self._local_path_data)
        t = QTransform()
        t.scale(sx, sy)
        return t.map(self._local_path_data)

    def to_dict(self):
        d = dict(self.__dict__)
        d["kind"] = self.kind
        # Le QPainterPath ne se sérialise pas tel quel : on le réduit en une
        # liste de polygones (mêmes points, robuste pour un save/load JSON).
        polys = self._local_path_data.toSubpathPolygons(QTransform())
        d["_local_polys"] = [[(p.x(), p.y()) for p in poly] for poly in polys]
        d.pop("_local_path_data", None)
        return d

    @staticmethod
    def from_dict(d):
        obj = SvgPathObject.__new__(SvgPathObject)
        data = dict(d)
        polys = data.pop("_local_polys", [])
        data.pop("kind", None)
        path = QPainterPath()
        for poly in polys:
            if not poly:
                continue
            path.moveTo(poly[0][0], poly[0][1])
            for (x, y) in poly[1:]:
                path.lineTo(x, y)
        obj.__dict__.update(data)
        obj._local_path_data = path
        obj.scale_x = data.get("scale_x", 1.0)
        obj.scale_y = data.get("scale_y", 1.0)
        return obj


def _svg_path_element_to_subpaths(d):
    """Convertit le 'd' d'un <path> SVG en une liste de QPainterPath
    INDÉPENDANTS, un par sous-tracé (une commande M/m démarre un nouveau
    sous-tracé). Utilisé par le dégroupage manuel (clic droit).

    Les courbes de Bézier sont converties EXACTEMENT (cubicTo/quadTo, pas
    d'échantillonnage) ; seuls les arcs (rares en pratique) sont échantillonnés
    faute d'équivalent direct dans QPainterPath."""
    parsed = parse_path(d)
    paths = []
    current = None
    for seg in parsed:
        if isinstance(seg, Move):
            if current is not None and current.elementCount() > 0:
                paths.append(current)
            current = QPainterPath()
            current.moveTo(seg.end.real, seg.end.imag)
            continue
        if current is None:
            current = QPainterPath()
            current.moveTo(seg.start.real, seg.start.imag)
        if isinstance(seg, (Line, Close)):
            current.lineTo(seg.end.real, seg.end.imag)
        elif isinstance(seg, CubicBezier):
            current.cubicTo(seg.control1.real, seg.control1.imag,
                             seg.control2.real, seg.control2.imag,
                             seg.end.real, seg.end.imag)
        elif isinstance(seg, QuadraticBezier):
            current.quadTo(seg.control.real, seg.control.imag,
                            seg.end.real, seg.end.imag)
        elif isinstance(seg, Arc):
            try:
                length = seg.length()
            except Exception:
                length = 0
            n = max(4, int(length / 0.3)) if length else 8
            for i in range(1, n + 1):
                pt = seg.point(i / n)
                current.lineTo(pt.real, pt.imag)
    if current is not None and current.elementCount() > 0:
        paths.append(current)
    return paths


def _svg_path_element_to_single(d):
    """Comme _svg_path_element_to_subpaths, mais renvoie UN seul QPainterPath
    contenant tous les sous-tracés (import groupé par défaut)."""
    combined = QPainterPath()
    for qp in _svg_path_element_to_subpaths(d):
        combined.addPath(qp)
    return combined


def _qpainterpath_to_subpaths(path):
    """Découpe un QPainterPath en sous-tracés indépendants (un par MoveTo).
    Préserve lignes et cubiques ; les autres types sont ramenés en lineTo."""
    paths = []
    current = None
    i = 0
    n = path.elementCount()
    while i < n:
        el = path.elementAt(i)
        et = el.type
        if et == QPainterPath.ElementType.MoveToElement:
            if current is not None and current.elementCount() > 0:
                paths.append(current)
            current = QPainterPath()
            current.moveTo(el.x, el.y)
            i += 1
        elif et == QPainterPath.ElementType.LineToElement:
            if current is None:
                current = QPainterPath()
                current.moveTo(el.x, el.y)
            else:
                current.lineTo(el.x, el.y)
            i += 1
        elif et == QPainterPath.ElementType.CurveToElement:
            # CurveTo + CurveToData + CurveToData
            if current is None:
                current = QPainterPath()
                current.moveTo(el.x, el.y)
                i += 1
                continue
            c1x, c1y = el.x, el.y
            if i + 2 < n:
                c2 = path.elementAt(i + 1)
                end = path.elementAt(i + 2)
                current.cubicTo(c1x, c1y, c2.x, c2.y, end.x, end.y)
                i += 3
            else:
                current.lineTo(c1x, c1y)
                i += 1
        else:
            if current is None:
                current = QPainterPath()
                current.moveTo(el.x, el.y)
            else:
                current.lineTo(el.x, el.y)
            i += 1
    if current is not None and current.elementCount() > 0:
        paths.append(current)
    return paths


def _merge_path_objects(objects, source_tag="group"):
    """Fusionne plusieurs SvgPathObject en un seul (même logique que group_selected).
    Les objets d'entrée doivent déjà être dans le repère monde cohérent."""
    if not objects:
        return None
    if len(objects) == 1:
        return objects[0]
    combined = QPainterPath()
    for obj in objects:
        combined.addPath(obj.world_path())
    bbox = combined.boundingRect()
    if bbox.isNull() or (bbox.width() <= 0 and bbox.height() <= 0):
        return objects[0]
    x0, y0 = bbox.left(), bbox.top()
    to_local = QTransform(1, 0, 0, -1, -x0, y0)
    local = to_local.map(combined)
    return SvgPathObject(
        local_path_data=local, source_tag=source_tag,
        layer_id=objects[0].layer_id, x_mm=x0, y_mm=y0,
    )


def extract_svg_objects(svg_path, layer_id, bed_h_mm, offset_x_mm=10.0, offset_y_mm=10.0,
                        ungroup=False):
    """Importe un fichier SVG dans l'éditeur vectoriel.

    Par défaut (`ungroup=False`), tout le dessin est importé comme **un seul**
    objet groupé : on le déplace / redimensionne / assigne à un calque d'un bloc.
    Le dégroupage (séparation en tracés indépendants) se fait ensuite à la
    demande via le menu contextuel (clic droit → Dégrouper).

    Avec `ungroup=True`, chaque tracé/sous-tracé devient un objet indépendant
    (ancien comportement).

    Convention : 1 unité SVG = 1 mm. Les positions relatives sont conservées ;
    l'ensemble est translaté pour ancrer son coin inférieur gauche à
    (offset_x_mm, offset_y_mm). Utilisé par l'import SVG, PNG→SVG, décor de
    boîte et Stencil Studio.
    """
    import xml.etree.ElementTree as ET

    tree = ET.parse(svg_path)
    root = tree.getroot()

    def local_tag(elem):
        return elem.tag.split('}')[-1]

    # Parent map pour retrouver le <g id="CUT|FRAME|ENGRAVE|LAYER_n"> englobant
    parent_map = {c: p for p in root.iter() for c in list(p)}

    def ancestor_group_id(elem):
        cur = elem
        while cur is not None:
            if local_tag(cur) == "g":
                gid = cur.attrib.get("id") or cur.attrib.get("label")
                if not gid:
                    # inkscape:label éventuel
                    for k, v in cur.attrib.items():
                        if k.endswith("label") and v:
                            gid = v
                            break
                if gid:
                    return str(gid).strip()
            cur = parent_map.get(cur)
        return None

    def source_tag_for(elem, geom_tag):
        gid = ancestor_group_id(elem)
        if gid:
            return f"svg:{gid}"
        return geom_tag

    raw = []  # (QPainterPath en coordonnées SVG brutes Y-bas, source_tag)

    for elem in root.iter():
        tag = local_tag(elem)
        try:
            if tag == 'path':
                d = elem.attrib.get('d')
                if not d:
                    continue
                st = source_tag_for(elem, tag)
                if ungroup:
                    # Sépare chaque sous-tracé (M/m) en objet indépendant.
                    for qp in _svg_path_element_to_subpaths(d):
                        raw.append((qp, st))
                else:
                    # Garde le <path> entier (éventuellement multi-sous-tracés)
                    # comme une seule géométrie ; le fusion globale plus bas
                    # regroupera aussi les autres éléments du fichier.
                    qp = _svg_path_element_to_single(d)
                    if qp.elementCount() > 0:
                        raw.append((qp, st))
            elif tag == 'rect':
                x = float(elem.attrib.get('x', 0)); y = float(elem.attrib.get('y', 0))
                w = float(elem.attrib.get('width', 0)); h = float(elem.attrib.get('height', 0))
                if w > 0 and h > 0:
                    qp = QPainterPath()
                    qp.addRect(x, y, w, h)
                    raw.append((qp, source_tag_for(elem, tag)))
            elif tag == 'circle':
                cx = float(elem.attrib.get('cx', 0)); cy = float(elem.attrib.get('cy', 0))
                r = float(elem.attrib.get('r', 0))
                if r > 0:
                    qp = QPainterPath()
                    qp.addEllipse(cx - r, cy - r, 2 * r, 2 * r)
                    raw.append((qp, source_tag_for(elem, tag)))
            elif tag == 'ellipse':
                cx = float(elem.attrib.get('cx', 0)); cy = float(elem.attrib.get('cy', 0))
                rx = float(elem.attrib.get('rx', 0)); ry = float(elem.attrib.get('ry', 0))
                if rx > 0 and ry > 0:
                    qp = QPainterPath()
                    qp.addEllipse(cx - rx, cy - ry, 2 * rx, 2 * ry)
                    raw.append((qp, source_tag_for(elem, tag)))
            elif tag in ('polygon', 'polyline'):
                pts_str = elem.attrib.get('points', '')
                coords = [float(v) for v in re.split(r'[\s,]+', pts_str.strip()) if v]
                if len(coords) >= 4:
                    poly = QPolygonF([QPointF(coords[i], coords[i + 1]) for i in range(0, len(coords) - 1, 2)])
                    qp = QPainterPath()
                    qp.addPolygon(poly)
                    if tag == 'polygon':
                        qp.closeSubpath()
                    raw.append((qp, source_tag_for(elem, tag)))
            elif tag == 'line':
                x1 = float(elem.attrib.get('x1', 0)); y1 = float(elem.attrib.get('y1', 0))
                x2 = float(elem.attrib.get('x2', 0)); y2 = float(elem.attrib.get('y2', 0))
                qp = QPainterPath()
                qp.moveTo(x1, y1)
                qp.lineTo(x2, y2)
                raw.append((qp, source_tag_for(elem, tag)))
        except Exception:
            continue

    objects = []
    for qp, tag in raw:
        bbox = qp.boundingRect()
        if bbox.width() <= 0 and bbox.height() <= 0:
            continue
        reanchor = QTransform()
        reanchor.translate(-bbox.left(), -bbox.bottom())
        local = reanchor.map(qp)

        world_x = bbox.left()
        world_y = bed_h_mm - bbox.bottom()

        obj = SvgPathObject(local_path_data=local, source_tag=tag,
                             layer_id=layer_id, x_mm=world_x, y_mm=world_y)
        objects.append(obj)

    if objects:
        # Translation en bloc de tout le dessin importé (positions relatives
        # entre tracés inchangées) pour ancrer son coin inférieur gauche à
        # l'offset demandé au lieu de l'ancrage brut issu du SVG.
        min_x = min(obj.x_mm for obj in objects)
        min_y = min(obj.y_mm for obj in objects)
        delta_x = offset_x_mm - min_x
        delta_y = offset_y_mm - min_y
        for obj in objects:
            obj.x_mm += delta_x
            obj.y_mm += delta_y

        # Import groupé : un seul objet pour tout le fichier.
        if not ungroup and len(objects) > 1:
            merged = _merge_path_objects(objects, source_tag="svg_group")
            if merged is not None:
                objects = [merged]

    return objects


# ============================================================================
# 3) CANEVAS VECTORIEL (édition à la souris)
# ============================================================================

class VectorGraphicsItem(QGraphicsPathItem):
    """QGraphicsItem qui représente un VectorObject sur le canevas (échelle px/mm).

    Le repère "monde" (VectorObject.world_transform) est bas-gauche / Y-haut,
    utilisé tel quel pour le G-Code. La scène Qt, elle, reste nativement
    Y-descendant (aucun flip au niveau de la QGraphicsView : fitInView() peut
    silencieusement annuler un flip posé sur la vue, ce qui cassait
    l'affichage). La conversion "monde -> écran" est donc calculée ici,
    objet par objet, directement dans la matrice de chaque item.
    """

    def __init__(self, obj: VectorObject, layer_manager: LayerManager, canvas: "VectorCanvasView"):
        super().__init__()
        self.obj = obj
        self.layer_manager = layer_manager
        self.canvas = canvas
        self.setFlags(
            QGraphicsItem.GraphicsItemFlag.ItemIsMovable |
            QGraphicsItem.GraphicsItemFlag.ItemIsSelectable |
            QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges
        )
        self.double_click_callback = None  # défini par VectorCanvasView.add_object
        self.refresh()

    def mouseDoubleClickEvent(self, event):
        if self.double_click_callback:
            self.double_click_callback()
        super().mouseDoubleClickEvent(event)

    def refresh(self):
        """Recalcule la forme affichée (mm -> px, repère écran) à partir du VectorObject."""
        s = self.canvas.px_per_mm
        work_h_px = self.canvas.work_h_mm * s

        local_path_px = QTransform().scale(s, s).map(self.obj.local_path())
        self.prepareGeometryChange()
        self.setPath(local_path_px)

        sx = -1.0 if self.obj.mirror_h else 1.0
        sy = 1.0 if self.obj.mirror_v else -1.0

        # Construit, dans une seule matrice, la transformation monde (position,
        # rotation, miroir) PUIS le passage bas-gauche/Y-haut -> écran Qt
        # Y-descendant. Avec QTransform, des appels .translate()/.rotate()/
        # .scale() enchaînés s'appliquent à un point dans l'ordre INVERSE des
        # appels : ci-dessous, un point est donc d'abord mis à l'échelle
        # (miroir), puis pivoté, puis positionné (repère monde), puis
        # seulement là le flip écran + décalage de hauteur sont appliqués.
        t = QTransform()
        t.translate(0, work_h_px)         # 5) décale pour repère écran Qt
        t.scale(1, -1)                    # 4) inverse Y : monde Y-haut -> écran Y-bas
        t.translate(self.obj.x_mm * s, self.obj.y_mm * s)  # 3) position (repère monde)
        t.rotate(self.obj.rotation_deg)   # 2) rotation
        t.scale(sx, sy)                   # 1) miroir éventuel
        self.setTransform(t)
        self.setPos(0, 0)

        layer = self.layer_manager.get(self.obj.layer_id)
        color = QColor(layer.color) if layer else QColor("#dddddd")
        pen = QPen(color, 1.4)
        pen.setCosmetic(True)
        self.setPen(pen)
        self.setBrush(QBrush(Qt.BrushStyle.NoBrush))

    def itemChange(self, change, value):
        if change == QGraphicsItem.GraphicsItemChange.ItemTransformHasChanged:
            pass
        return super().itemChange(change, value)

    def sync_position_from_scene(self):
        """À appeler après un déplacement souris : remet x_mm/y_mm à jour à
        partir de la position écran (en tenant compte du flip Y bas-gauche)."""
        pos = self.scenePos()
        s = self.canvas.px_per_mm
        work_h_px = self.canvas.work_h_mm * s
        self.obj.x_mm = pos.x() / s
        self.obj.y_mm = (work_h_px - pos.y()) / s


class VectorCanvasView(QGraphicsView):
    """Vue d'édition : zone de travail en mm, objets déplaçables à la souris,
    coloration selon le calque. Indépendante des vues image (aucun impact
    sur les performances du tramage)."""

    selection_changed = pyqtSignal(object)  # VectorObject ou None
    object_moved = pyqtSignal(object)       # VectorObject déplacé à la souris
    edit_requested = pyqtSignal(object)     # double-clic sur un objet

    def __init__(self, layer_manager: LayerManager, parent=None):
        super().__init__(parent)
        self.layer_manager = layer_manager
        self.objects = []  # list[VectorObject]
        self.px_per_mm = 4.0
        self.grid_items = []

        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        self.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        self.setBackgroundBrush(QColor("#1c1c1c"))
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        # Repère "machine" : origine en bas-gauche, Y croissant vers le haut.
        # (Le flip est calculé objet par objet et pour la grille — voir
        # VectorGraphicsItem.refresh et _draw_grid — plutôt qu'au niveau de la
        # vue : un flip posé sur la QGraphicsView pouvait être silencieusement
        # annulé par fitInView(), ce qui cassait tout l'alignement.)
        self._pan_last_pos = None
        self._undo_stack = []
        self._redo_stack = []
        self._max_undo = 30
        self._group_drag_items = []
        self._group_drag_last_scene_pos = None
        self._group_drag_anchor_item = None
        # Accroche à la grille pendant un déplacement à la souris (voir
        # mouseMoveEvent) : désactivée par défaut, réglable depuis la barre
        # d'outils de l'Éditeur Vectoriel (case + pas en mm).
        self.snap_enabled = False
        self.snap_step_mm = 5.0
        # Outil de dessin à la souris : None = sélection, sinon "line" / "rect" / "ellipse".
        self._draw_tool = None
        self._draw_start_scene = None
        self._draw_preview_item = None
        self._draw_layer_id = None
        # Accroche aux extrémités des tracés existants pendant le dessin
        self.endpoint_snap_enabled = True
        self.endpoint_snap_px = 12.0  # rayon d'accroche en pixels écran
        self._snap_indicator = None  # marqueur visuel du point d'accroche
        # Saisie de dimensions au clavier après le 1er point (ex: "25" ou "30x20")
        self._draw_dim_buffer = ""
        self._draw_last_cursor_scene = None
        # Phases : None → "p1" (2e clic) → "p2" (prêt à tirer) → "depth" (en train de tirer)
        self._draw_phase = None
        self._draw_base_p1 = None
        self._draw_base_p2 = None
        self._draw_awaiting_second = False
        self._draw_awaiting_depth = False
        self._draw_depth_dragging = False
        # Outil mesure : deux clics → distance affichée
        self._measure_p1 = None
        self._measure_preview = None
        self._measure_labels = []  # annotations persistantes jusqu'à nouvel outil
        # Mode édition de nœuds (sommets d'un SvgPathObject)
        self._node_mode = False
        self._node_target_item = None
        self._node_handles = []
        self._node_polylines = []  # list[list[QPointF]] en coordonnées locales objet
        self._node_drag_index = None  # (poly_idx, pt_idx) pendant un drag
        self._node_drag_pushed_undo = False
        # Recentrage différé de la vue (voir request_recenter) : attend la
        # fin des redimensionnements (plein écran, changement d'onglet)
        # avant de centrer, sinon la taille du viewport est encore fausse.
        self._recenter_items = None
        self._recenter_pending = False
        self._recenter_timer = QTimer(self)
        self._recenter_timer.setSingleShot(True)
        self._recenter_timer.timeout.connect(self._do_recenter)

        self.work_rect_item = None
        self.set_work_area(100.0, 100.0)

        self.scene_obj.selectionChanged.connect(self._on_selection_changed)

    # -- zone de travail ----------------------------------------------------
    def request_recenter(self, items=None):
        """Demande de centrer la vue sur `items` (liste de VectorGraphicsItem),
        ou à défaut sur la sélection, ou à défaut sur tous les objets. Le
        recentrage est différé et re-planifié à chaque redimensionnement
        (voir resizeEvent) : il s'exécute une fois la fenêtre / l'onglet
        réellement affiché à sa taille définitive."""
        self._recenter_items = list(items) if items else None
        self._recenter_pending = True
        self._recenter_timer.start(120)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._recenter_pending:
            self._recenter_timer.start(120)

    def _do_recenter(self):
        self._recenter_pending = False
        items = self._recenter_items
        self._recenter_items = None
        self.center_on_items(items)

    def center_on_items(self, items=None, margin_px=40, max_scale=10.0):
        """Cadre la vue sur la boîte englobante de `items` (sinon la
        sélection, sinon tous les objets, sinon la zone de travail) : zoom
        ajusté pour que l'ensemble remplisse la fenêtre (avec une marge), et
        centré au milieu. Le zoom est plafonné (`max_scale`) pour qu'un tout
        petit objet ne soit pas agrandi démesurément."""
        rect = QRectF()
        candidates = items if items else (self.selected_items_vector() or [
            i for i in self.scene_obj.items() if isinstance(i, VectorGraphicsItem)
        ])
        for it in candidates:
            try:
                if it.scene() is self.scene_obj:
                    rect = rect.united(it.sceneBoundingRect())
            except RuntimeError:
                pass  # objet supprimé entre-temps
        if rect.isNull() and self.work_rect_item:
            rect = self.work_rect_item.sceneBoundingRect()
        if rect.isNull():
            return

        vp = self.viewport().size()
        if vp.width() <= 2 * margin_px or vp.height() <= 2 * margin_px:
            return  # vue pas encore affichée à sa taille définitive

        # Zoom qui fait tenir l'ensemble dans la fenêtre, marge comprise.
        target = min(
            (vp.width() - 2 * margin_px) / max(rect.width(), 1e-6),
            (vp.height() - 2 * margin_px) / max(rect.height(), 1e-6),
            max_scale,
        )

        # Zone de la scène assez grande pour que la cible puisse être
        # réellement centrée (un QGraphicsView ne défile pas au-delà de sa
        # sceneRect : sans ça, un objet près de l'origine resterait
        # décentré). Recalculée à chaque fois depuis la zone de travail,
        # pour ne pas grossir indéfiniment.
        half_w = vp.width() / 2.0 / target
        half_h = vp.height() / 2.0 / target
        center = rect.center()
        needed = QRectF(center.x() - half_w, center.y() - half_h, 2 * half_w, 2 * half_h)
        base = QRectF()
        if self.work_rect_item:
            base = self.work_rect_item.sceneBoundingRect().adjusted(-50, -50, 50, 50)
        self.scene_obj.setSceneRect(base.united(rect.adjusted(-50, -50, 50, 50)).united(needed))

        self.resetTransform()
        self.scale(target, target)
        self.centerOn(center)

    def set_work_area(self, w_mm, h_mm):
        self.work_w_mm, self.work_h_mm = w_mm, h_mm
        if self.work_rect_item:
            self.scene_obj.removeItem(self.work_rect_item)
        for item in self.grid_items:
            self.scene_obj.removeItem(item)
        self.grid_items = []

        s = self.px_per_mm
        rect = QRectF(0, 0, w_mm * s, h_mm * s)
        self.work_rect_item = QGraphicsRectItem(rect)
        pen = QPen(QColor("#666666"), 1)
        pen.setCosmetic(True)
        self.work_rect_item.setPen(pen)
        self.work_rect_item.setZValue(-100)
        self.scene_obj.addItem(self.work_rect_item)

        self._draw_grid(w_mm, h_mm)

        self.scene_obj.setSceneRect(rect.adjusted(-50, -50, 50, 50))
        self.fitInView(rect, Qt.AspectRatioMode.KeepAspectRatio)

    def _draw_grid(self, w_mm, h_mm):
        """Grille en mm avec repères chiffrés le long des bords bas et gauche,
        pour se repérer facilement (origine = coin bas-gauche = 0,0). Les
        coordonnées écran sont calculées directement en Y inversé (bas-gauche
        -> Y-descendant Qt) : aucun flip de vue n'est utilisé (voir __init__),
        donc pas besoin de contre-flip sur les étiquettes non plus.
        """
        s = self.px_per_mm
        work_h_px = h_mm * s
        span = max(w_mm, h_mm)
        # Paliers plus fins qu'avant (l'ancien "50mm partout au-delà de 200mm"
        # était trop grossier pour se repérer précisément sur une zone de
        # travail courante de 200-400mm).
        if span <= 50:
            step = 5
        elif span <= 150:
            step = 10
        elif span <= 400:
            step = 20
        elif span <= 1000:
            step = 50
        else:
            step = 100
        minor_step = step / 4.0

        minor_pen = QPen(QColor("#262626"), 0)
        minor_pen.setCosmetic(True)

        grid_pen = QPen(QColor("#333333"), 0)
        grid_pen.setCosmetic(True)

        # Lignes mineures (sans étiquette) pour un repérage plus précis entre
        # deux graduations principales.
        xm = minor_step
        while xm < w_mm - 1e-6:
            line = self.scene_obj.addLine(xm * s, 0, xm * s, work_h_px, minor_pen)
            line.setZValue(-95)
            self.grid_items.append(line)
            xm += minor_step
        ym = minor_step
        while ym < h_mm - 1e-6:
            screen_y = work_h_px - ym * s
            line = self.scene_obj.addLine(0, screen_y, w_mm * s, screen_y, minor_pen)
            line.setZValue(-95)
            self.grid_items.append(line)
            ym += minor_step

        x = 0.0
        while x <= w_mm + 1e-6:
            line = self.scene_obj.addLine(x * s, 0, x * s, work_h_px, grid_pen)
            line.setZValue(-90)
            self.grid_items.append(line)
            label = self.scene_obj.addSimpleText(f"{x:g}")
            label.setBrush(QColor("#999999"))
            label.setPos(x * s + 2, work_h_px - 16)
            label.setZValue(-80)
            self.grid_items.append(label)
            x += step

        y = 0.0
        while y <= h_mm + 1e-6:
            screen_y = work_h_px - y * s
            line = self.scene_obj.addLine(0, screen_y, w_mm * s, screen_y, grid_pen)
            line.setZValue(-90)
            self.grid_items.append(line)
            label = self.scene_obj.addSimpleText(f"{y:g}")
            label.setBrush(QColor("#999999"))
            label.setPos(2, screen_y - 16)
            label.setZValue(-80)
            self.grid_items.append(label)
            y += step

        origin_label = self.scene_obj.addSimpleText("0,0 (origine)")
        origin_label.setBrush(QColor("#ff8844"))
        origin_label.setPos(2, work_h_px - 32)
        origin_label.setZValue(-80)
        self.grid_items.append(origin_label)

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)

    def scene_to_mm(self, scene_pos):
        """Point scène Qt (Y bas) -> millimètres machine (origine bas-gauche, Y haut)."""
        s = self.px_per_mm
        work_h_px = self.work_h_mm * s
        return scene_pos.x() / s, (work_h_px - scene_pos.y()) / s

    def mm_to_scene(self, x_mm, y_mm):
        """Millimètres machine (Y haut) -> point scène Qt (Y bas)."""
        s = self.px_per_mm
        work_h_px = self.work_h_mm * s
        return QPointF(x_mm * s, work_h_px - y_mm * s)

    def set_draw_tool(self, tool, layer_id=None):
        """Active un outil : None/'select', 'line', 'rect', 'ellipse', 'measure'."""
        self._cancel_draw_preview()
        self._clear_measure_temp()
        if tool in (None, "", "select"):
            self._draw_tool = None
            self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
            self.setCursor(Qt.CursorShape.ArrowCursor)
        else:
            self._draw_tool = tool
            self._draw_layer_id = layer_id
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
            self.setCursor(Qt.CursorShape.CrossCursor)
            self.scene_obj.clearSelection()
            self.setFocus(Qt.FocusReason.OtherFocusReason)

    def _cancel_draw_preview(self):
        if self._draw_preview_item is not None:
            try:
                self.scene_obj.removeItem(self._draw_preview_item)
            except RuntimeError:
                pass
            self._draw_preview_item = None
        self._hide_snap_indicator()
        self._draw_start_scene = None
        self._draw_dim_buffer = ""
        self._draw_last_cursor_scene = None
        self._draw_base_p1 = None
        self._draw_base_p2 = None
        self._draw_phase = None
        self._draw_awaiting_second = False
        self._draw_awaiting_depth = False
        self._draw_depth_dragging = False

    def _clear_measure_temp(self):
        self._measure_p1 = None
        if self._measure_preview is not None:
            try:
                self.scene_obj.removeItem(self._measure_preview)
            except RuntimeError:
                pass
            self._measure_preview = None

    def clear_measure_labels(self):
        for it in self._measure_labels:
            try:
                self.scene_obj.removeItem(it)
            except RuntimeError:
                pass
        self._measure_labels = []

    def _default_draw_layer_id(self):
        if self._draw_layer_id:
            return self._draw_layer_id
        layer = self.layer_manager.default_svg_layer()
        return layer.id if layer else (self.layer_manager.layers[0].id if self.layer_manager.layers else None)

    def _preview_pen(self):
        layer = self.layer_manager.get(self._default_draw_layer_id())
        color = QColor(layer.color) if layer else QColor("#00aaff")
        pen = QPen(color, 1.5, Qt.PenStyle.DashLine)
        pen.setCosmetic(True)
        return pen

    # -- Accroche aux extrémités (dessin) ------------------------------------

    def _collect_endpoint_scene_points(self):
        """Extrémités (et coins) de tous les objets vectoriels, en coords scène."""
        pts = []
        for item in self.scene_obj.items():
            if not isinstance(item, VectorGraphicsItem):
                continue
            # Pendant le dessin, l'aperçu n'est pas un VectorGraphicsItem
            try:
                world = item.obj.world_path()
            except Exception:
                continue
            for poly in world.toSubpathPolygons(QTransform()):
                if poly.count() < 1:
                    continue
                # Extrémités de polyligne
                for idx in (0, poly.count() - 1):
                    p = poly.at(idx)
                    x_mm, y_mm = p.x(), p.y()
                    # world_path est déjà en mm monde Y-haut
                    pts.append(self.mm_to_scene(x_mm, y_mm))
                # Tous les sommets (utile pour repartir d'un coin d'encoche)
                for i in range(poly.count()):
                    p = poly.at(i)
                    pts.append(self.mm_to_scene(p.x(), p.y()))
        return pts

    def _snap_scene_pos(self, scene_pos):
        """Accroche scene_pos à l'extrémité / sommet le plus proche si dans le rayon."""
        if not self.endpoint_snap_enabled:
            return scene_pos, False
        view_scale = max(abs(self.transform().m11()), 0.01)
        max_d = self.endpoint_snap_px / view_scale
        max_d2 = max_d * max_d
        best = None
        best_d2 = max_d2
        for p in self._collect_endpoint_scene_points():
            dx = p.x() - scene_pos.x()
            dy = p.y() - scene_pos.y()
            d2 = dx * dx + dy * dy
            if d2 <= best_d2:
                best_d2 = d2
                best = p
        if best is not None:
            return QPointF(best), True
        return scene_pos, False

    def _show_snap_indicator(self, scene_pos):
        view_scale = max(abs(self.transform().m11()), 0.01)
        r = 6.0 / view_scale
        if self._snap_indicator is None:
            self._snap_indicator = QGraphicsEllipseItem()
            self._snap_indicator.setBrush(QBrush(QColor(255, 200, 0, 180)))
            self._snap_indicator.setPen(QPen(QColor("#222222"), 0))
            self._snap_indicator.setZValue(3000)
            self.scene_obj.addItem(self._snap_indicator)
        self._snap_indicator.setRect(scene_pos.x() - r, scene_pos.y() - r, 2 * r, 2 * r)
        self._snap_indicator.setVisible(True)

    def _hide_snap_indicator(self):
        if self._snap_indicator is not None:
            self._snap_indicator.setVisible(False)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.MiddleButton:
            self._pan_last_pos = event.position().toPoint()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return

        # Clic droit en mode dessin : annule l'outil et revient à la sélection.
        if event.button() == Qt.MouseButton.RightButton and self._draw_tool:
            self.set_draw_tool(None)
            event.accept()
            return

        # Mode nœuds : clic gauche = sélection / début de drag d'un sommet
        if event.button() == Qt.MouseButton.LeftButton and self._node_mode:
            scene_pos = self.mapToScene(event.position().toPoint())
            hit = self._hit_node_handle(scene_pos)
            if hit is not None:
                self._node_drag_index = hit
                self._node_drag_pushed_undo = False
                event.accept()
                return
            # Double-clic géré séparément ; simple clic sur segment = rien
            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton and self._draw_tool == "measure":
            raw = self.mapToScene(event.position().toPoint())
            pt, snapped = self._snap_scene_pos(raw)
            if snapped:
                self._show_snap_indicator(pt)
            if self._measure_p1 is None:
                self._measure_p1 = pt
                if self._measure_preview is None:
                    self._measure_preview = self.scene_obj.addPath(QPainterPath(), self._preview_pen())
                    self._measure_preview.setZValue(1000)
            else:
                self._finalize_measure(self._measure_p1, pt)
                self._measure_p1 = None
                if self._measure_preview is not None:
                    try:
                        self.scene_obj.removeItem(self._measure_preview)
                    except RuntimeError:
                        pass
                    self._measure_preview = None
                self._hide_snap_indicator()
            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton and self._draw_tool in ("line", "rect", "ellipse"):
            if not self.layer_manager.layers:
                event.accept()
                return
            raw = self.mapToScene(event.position().toPoint())
            pt, snapped = self._snap_scene_pos(raw)
            if snapped:
                self._show_snap_indicator(pt)

            phase = self._draw_phase

            # --- Phase profondeur : début du TIRÉ (après les 2 clics nœuds) ---
            if (
                phase in ("p2", "depth")
                and self._draw_tool in ("rect", "ellipse")
                and self._draw_base_p1 is not None
                and self._draw_base_p2 is not None
            ):
                self._draw_phase = "depth"
                self._draw_depth_dragging = True
                self._draw_awaiting_depth = True
                self._draw_last_cursor_scene = pt
                event.accept()
                return

            # --- Phase p1 : 2e CLIC (pas de tiré) → place le 2e nœud ---
            if phase == "p1" and self._draw_start_scene is not None:
                if self._draw_tool == "line":
                    start = self._draw_start_scene
                    self._cancel_draw_preview()
                    obj = self._create_drawn_object(start, pt)
                    if obj is not None:
                        self.push_undo_snapshot()
                        item = self.add_object(obj)
                        self.scene_obj.clearSelection()
                        item.setSelected(True)
                    event.accept()
                    return
                # Rect / ellipse : largeur figée, on n'autorise le tiré QU'après ce clic
                self._draw_base_p1 = QPointF(self._draw_start_scene)
                self._draw_base_p2 = QPointF(pt)
                self._draw_phase = "p2"
                self._draw_awaiting_second = False
                self._draw_awaiting_depth = True
                self._draw_depth_dragging = False
                self._draw_dim_buffer = ""
                self._draw_last_cursor_scene = pt
                if self._draw_preview_item is None:
                    self._draw_preview_item = self.scene_obj.addPath(
                        QPainterPath(), self._preview_pen()
                    )
                    self._draw_preview_item.setZValue(1000)
                # Aperçu = segment de base uniquement (pas encore de profondeur)
                path = QPainterPath()
                path.moveTo(self._draw_base_p1)
                path.lineTo(self._draw_base_p2)
                self._draw_preview_item.setPath(path)
                self._draw_preview_item.setPen(self._preview_pen())
                event.accept()
                return

            # --- Phase None : 1er CLIC ---
            if phase is None:
                self._draw_start_scene = pt
                self._draw_phase = "p1"
                self._draw_awaiting_second = True
                self._draw_awaiting_depth = False
                self._draw_depth_dragging = False
                self._draw_base_p1 = None
                self._draw_base_p2 = None
                self._draw_dim_buffer = ""
                self._draw_last_cursor_scene = pt
                if self._draw_preview_item is None:
                    self._draw_preview_item = self.scene_obj.addPath(
                        QPainterPath(), self._preview_pen()
                    )
                    self._draw_preview_item.setZValue(1000)
                event.accept()
                return

            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton:
            item_at = self.itemAt(event.position().toPoint())

            if isinstance(item_at, VectorGraphicsItem):
                modifiers = event.modifiers()

                if modifiers & Qt.KeyboardModifier.ControlModifier:
                    # Ctrl + clic : ajoute l'objet à la sélection (ou le
                    # retire s'il en faisait déjà partie), sans toucher au
                    # reste de la sélection.
                    new_state = not item_at.isSelected()
                    item_at.setSelected(new_state)
                    if not new_state:
                        # Objet désélectionné : simple bascule, pas de
                        # déplacement groupé à démarrer.
                        event.accept()
                        return
                elif not item_at.isSelected():
                    # Sans Ctrl : si l'objet cliqué ne fait pas déjà partie
                    # de la sélection, il devient l'unique objet sélectionné.
                    self.scene_obj.clearSelection()
                    item_at.setSelected(True)

                selected = self.selected_items_vector()

                if selected:
                    self.push_undo_snapshot()
                    self._group_drag_items = selected
                    self._group_drag_anchor_item = item_at
                    self._group_drag_last_scene_pos = self.mapToScene(
                        event.position().toPoint()
                    )
                    event.accept()
                    return

        # Permet de conserver la sélection rectangulaire par cliquer-glisser
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._pan_last_pos is not None and (
            event.buttons() & Qt.MouseButton.MiddleButton
        ):
            new_pos = event.position().toPoint()
            delta = new_pos - self._pan_last_pos
            self._pan_last_pos = new_pos

            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - delta.x()
            )
            self.verticalScrollBar().setValue(
                self.verticalScrollBar().value() - delta.y()
            )
            event.accept()
            return

        # Drag d'un nœud
        if (
            self._node_mode
            and self._node_drag_index is not None
            and event.buttons() & Qt.MouseButton.LeftButton
        ):
            if not self._node_drag_pushed_undo:
                self.push_undo_snapshot()
                self._node_drag_pushed_undo = True
            scene_pos = self.mapToScene(event.position().toPoint())
            local = self._scene_to_local(scene_pos)
            pi, vi = self._node_drag_index
            if pi < len(self._node_polylines) and vi < len(self._node_polylines[pi]):
                self._node_polylines[pi][vi] = local
                # Mise à jour légère : rebuild path + handles
                item = self._node_target_item
                if item is not None and isinstance(item.obj, SvgPathObject):
                    path = self._polylines_to_path(self._node_polylines)
                    sx = getattr(item.obj, "scale_x", 1.0) or 1.0
                    sy = getattr(item.obj, "scale_y", 1.0) or 1.0
                    if abs(sx - 1.0) > 1e-9 or abs(sy - 1.0) > 1e-9:
                        t = QTransform()
                        t.scale(1.0 / sx, 1.0 / sy)
                        path = t.map(path)
                    item.obj._local_path_data = path
                    item.refresh()
                    # Déplace juste le handle concerné
                    for h in self._node_handles:
                        data = h.data(0)
                        if data and data[0] == "node" and data[1] == pi and data[2] == vi:
                            view_scale = max(self.transform().m11(), 0.01)
                            r = 5.0 / view_scale
                            sp = self._local_to_scene(local)
                            h.setRect(sp.x() - r, sp.y() - r, 2 * r, 2 * r)
                            break
            event.accept()
            return

        # Aperçu profondeur : UNIQUEMENT pendant le tiré (bouton enfoncé)
        if (
            self._draw_tool in ("rect", "ellipse")
            and self._draw_depth_dragging
            and self._draw_base_p1 is not None
            and self._draw_base_p2 is not None
            and self._draw_preview_item is not None
        ):
            raw = self.mapToScene(event.position().toPoint())
            end, snapped = self._snap_scene_pos(raw)
            self._draw_last_cursor_scene = end
            if snapped:
                self._show_snap_indicator(end)
            else:
                self._hide_snap_indicator()
            depth = self._depth_from_cursor(self._draw_base_p1, self._draw_base_p2, end)
            path = self._preview_path_base_depth(
                self._draw_base_p1, self._draw_base_p2, depth,
                ellipse=(self._draw_tool == "ellipse"),
            )
            self._draw_preview_item.setPath(path)
            self._draw_preview_item.setPen(self._preview_pen())
            event.accept()
            return

        # Phase p2 (base fixée, pas encore de tiré) : segment fixe + accroche
        if (
            self._draw_tool in ("rect", "ellipse")
            and self._draw_phase == "p2"
            and self._draw_base_p1 is not None
            and self._draw_base_p2 is not None
            and self._draw_preview_item is not None
        ):
            raw = self.mapToScene(event.position().toPoint())
            end, snapped = self._snap_scene_pos(raw)
            self._draw_last_cursor_scene = end
            if snapped:
                self._show_snap_indicator(end)
            else:
                self._hide_snap_indicator()
            path = QPainterPath()
            path.moveTo(self._draw_base_p1)
            path.lineTo(self._draw_base_p2)
            self._draw_preview_item.setPath(path)
            self._draw_preview_item.setPen(self._preview_pen())
            event.accept()
            return

        # Phase p1 : ligne du 1er point vers le curseur (sans tenir le bouton)
        if (
            self._draw_tool in ("line", "rect", "ellipse")
            and self._draw_phase == "p1"
            and self._draw_start_scene is not None
            and self._draw_preview_item is not None
        ):
            raw_end = self.mapToScene(event.position().toPoint())
            end, snapped = self._snap_scene_pos(raw_end)
            self._draw_last_cursor_scene = end
            if snapped:
                self._show_snap_indicator(end)
            else:
                self._hide_snap_indicator()
            path = QPainterPath()
            path.moveTo(self._draw_start_scene)
            path.lineTo(end)
            self._draw_preview_item.setPath(path)
            self._draw_preview_item.setPen(self._preview_pen())
            event.accept()
            return

        # Aperçu mesure
        if self._draw_tool == "measure" and self._measure_p1 is not None:
            raw = self.mapToScene(event.position().toPoint())
            end, snapped = self._snap_scene_pos(raw)
            if snapped:
                self._show_snap_indicator(end)
            else:
                self._hide_snap_indicator()
            if self._measure_preview is not None:
                path = QPainterPath()
                path.moveTo(self._measure_p1)
                path.lineTo(end)
                self._measure_preview.setPath(path)
            event.accept()
            return

        # Survol outil dessin/mesure : prévisualise l'accroche
        if self._draw_tool and not (event.buttons() & Qt.MouseButton.LeftButton):
            raw = self.mapToScene(event.position().toPoint())
            snapped_pos, snapped = self._snap_scene_pos(raw)
            if snapped:
                self._show_snap_indicator(snapped_pos)
            else:
                self._hide_snap_indicator()

        # Déplacement groupé des objets sélectionnés
        if (
            self._group_drag_items
            and event.buttons() & Qt.MouseButton.LeftButton
            and self._group_drag_last_scene_pos is not None
        ):
            current_scene_pos = self.mapToScene(event.position().toPoint())
            delta = current_scene_pos - self._group_drag_last_scene_pos

            if delta.x() or delta.y():
                delta_x_mm = delta.x() / self.px_per_mm
                delta_y_mm = -delta.y() / self.px_per_mm

                for item in self._group_drag_items:
                    item.obj.x_mm += delta_x_mm
                    item.obj.y_mm += delta_y_mm

                # Accroche à la grille : on ne recale QUE l'objet réellement
                # cliqué (l'ancre) sur le pas de grille, puis on répercute le
                # même petit correctif sur le reste de la sélection — plutôt
                # que d'accrocher chaque objet indépendamment, ce qui
                # déformerait l'agencement relatif d'une sélection multiple.
                if (
                    self.snap_enabled
                    and self.snap_step_mm > 0
                    and self._group_drag_anchor_item is not None
                ):
                    anchor = self._group_drag_anchor_item
                    snapped_x = round(anchor.obj.x_mm / self.snap_step_mm) * self.snap_step_mm
                    snapped_y = round(anchor.obj.y_mm / self.snap_step_mm) * self.snap_step_mm
                    corr_x = snapped_x - anchor.obj.x_mm
                    corr_y = snapped_y - anchor.obj.y_mm
                    if corr_x or corr_y:
                        for item in self._group_drag_items:
                            item.obj.x_mm += corr_x
                            item.obj.y_mm += corr_y

                for item in self._group_drag_items:
                    item.refresh()

                self._group_drag_last_scene_pos = current_scene_pos

            event.accept()
            return

        super().mouseMoveEvent(event)

    # -- gestion des objets ---------------------------------------------------
    def add_object(self, obj: VectorObject):
        self.objects.append(obj)
        item = VectorGraphicsItem(obj, self.layer_manager, self)
        item.double_click_callback = lambda o=obj: self.edit_requested.emit(o)
        self.scene_obj.addItem(item)
        return item

    def remove_selected(self):
        self.exit_node_edit()
        self.push_undo_snapshot()
        for item in list(self.scene_obj.selectedItems()):
            if isinstance(item, VectorGraphicsItem):
                try:
                    self.objects.remove(item.obj)
                except ValueError:
                    pass
                self.scene_obj.removeItem(item)

    def duplicate_selected(self):
        self.push_undo_snapshot()
        new_items = []
        for item in list(self.scene_obj.selectedItems()):
            if isinstance(item, VectorGraphicsItem):
                clone = VectorObject.from_dict(item.obj.to_dict())
                clone.id = uuid.uuid4().hex[:8]
                clone.x_mm += 5
                clone.y_mm += 5
                new_items.append(self.add_object(clone))
        return new_items

    def group_selected(self):
        """Regroupe les objets sélectionnés (Ctrl+clic, rectangle ou Ctrl+A)
        en UN SEUL objet tracé (SvgPathObject) : la géométrie de chaque
        partie est reprise telle qu'elle est actuellement positionnée sur
        le canevas (position, rotation, miroir, taille), puis fusionnée.
        Le nouvel objet se déplace / se redimensionne / change de calque
        comme un tout. Le calque retenu est celui de l'objet le plus ancien
        de la sélection. Annulable avec Ctrl+Z. Renvoie le nouvel item, ou
        None si moins de 2 objets sont sélectionnés."""
        items = self.selected_items_vector()
        if len(items) < 2:
            return None
        order = {id(o): i for i, o in enumerate(self.objects)}
        items.sort(key=lambda it: order.get(id(it.obj), 0))

        combined = QPainterPath()
        for it in items:
            combined.addPath(it.obj.world_path())
        bbox = combined.boundingRect()
        if bbox.isNull():
            return None

        self.push_undo_snapshot()

        # Repère monde (origine bas-gauche, Y vers le haut) -> repère local
        # d'un SvgPathObject (ancré sur le coin bas-gauche de la boîte
        # englobante, Y vers le bas), comme dans extract_svg_objects.
        x0, y0 = bbox.left(), bbox.top()
        to_local = QTransform(1, 0, 0, -1, -x0, y0)
        local = to_local.map(combined)

        group_obj = SvgPathObject(
            local_path_data=local, source_tag="group",
            layer_id=items[0].obj.layer_id, x_mm=x0, y_mm=y0,
        )

        for it in items:
            self.objects.remove(it.obj)
            self.scene_obj.removeItem(it)
        new_item = self.add_object(group_obj)
        new_item.setSelected(True)
        return new_item

    def _can_ungroup_item(self, item):
        """True si l'item est un SvgPathObject avec au moins 2 sous-tracés."""
        obj = getattr(item, "obj", None)
        if not isinstance(obj, SvgPathObject):
            return False
        subs = _qpainterpath_to_subpaths(obj.local_path())
        return len(subs) >= 2

    def ungroup_selected(self):
        """Dégroupe les SvgPathObject sélectionnés : chaque sous-tracé devient
        un objet indépendant (sélectionnable, assignable à un autre calque).
        Inverse de group_selected / de l'import groupé. Annulable (Ctrl+Z).
        Renvoie la liste des nouveaux items créés."""
        items = self.selected_items_vector()
        expandable = [it for it in items if self._can_ungroup_item(it)]
        if not expandable:
            return []

        self.push_undo_snapshot()
        new_items = []
        for it in expandable:
            obj = it.obj
            subs = _qpainterpath_to_subpaths(obj.local_path())
            # Transforme chaque sous-tracé local en objet monde indépendant.
            # world_transform mappe le repère local de l'objet parent.
            wt = obj.world_transform()
            children = []
            for sub in subs:
                if sub.elementCount() == 0:
                    continue
                world_sub = wt.map(sub)
                bbox = world_sub.boundingRect()
                if bbox.width() <= 0 and bbox.height() <= 0:
                    continue
                x0, y0 = bbox.left(), bbox.top()
                to_local = QTransform(1, 0, 0, -1, -x0, y0)
                local = to_local.map(world_sub)
                child = SvgPathObject(
                    local_path_data=local,
                    source_tag=getattr(obj, "source_tag", "path") or "path",
                    layer_id=obj.layer_id,
                    x_mm=x0,
                    y_mm=y0,
                )
                children.append(child)

            if len(children) < 2:
                # Rien d'utile à séparer : on laisse l'objet tel quel.
                continue

            self.objects.remove(obj)
            self.scene_obj.removeItem(it)
            for child in children:
                new_items.append(self.add_object(child))

        for it in new_items:
            it.setSelected(True)
        return new_items

    # ------------------------------------------------------------------
    # Exploser en segments + édition de nœuds
    # ------------------------------------------------------------------

    @staticmethod
    def _path_to_polylines(path: QPainterPath):
        """Convertit un QPainterPath en polylignes (liste de listes de QPointF).

        Les courbes sont aplaties via toSubpathPolygons (précision suffisante
        pour l'édition laser : segments / encoches).
        """
        polylines = []
        for poly in path.toSubpathPolygons(QTransform()):
            pts = [QPointF(p) for p in poly]
            if len(pts) >= 2:
                polylines.append(pts)
        return polylines

    @staticmethod
    def _polylines_to_path(polylines):
        path = QPainterPath()
        for pts in polylines:
            if len(pts) < 2:
                continue
            path.moveTo(pts[0])
            for p in pts[1:]:
                path.lineTo(p)
        return path

    @staticmethod
    def _world_path_to_svg_object(world_path: QPainterPath, layer_id, source_tag="segment"):
        """Crée un SvgPathObject ancré sur le bbox monde d'un petit tracé."""
        bbox = world_path.boundingRect()
        if bbox.width() <= 0 and bbox.height() <= 0:
            # Segment purement horizontal/vertical : bbox peut avoir une dim nulle.
            if world_path.elementCount() == 0:
                return None
        x0, y0 = bbox.left(), bbox.top()
        # Même convention que group/ungroup : Y monde haut -> local avec flip
        to_local = QTransform(1, 0, 0, -1, -x0, y0)
        local = to_local.map(world_path)
        return SvgPathObject(
            local_path_data=local,
            source_tag=source_tag,
            layer_id=layer_id,
            x_mm=x0,
            y_mm=y0,
        )

    def _can_explode_item(self, item):
        obj = getattr(item, "obj", None)
        if obj is None:
            return False
        # Tout objet avec une géométrie de chemin (forme, svg, texte) peut être explosé
        # en segments s'il a au moins une arête.
        path = obj.world_path()
        polys = self._path_to_polylines(path)
        n_edges = sum(max(0, len(pts) - 1) for pts in polys)
        return n_edges >= 1

    def explode_selected(self):
        """Découpe chaque objet sélectionné en **segments indépendants**
        (une ligne = un objet). Permet de supprimer une seule encoche ou un
        seul trait puis de le redessiner. Annulable (Ctrl+Z)."""
        self.exit_node_edit()
        items = self.selected_items_vector()
        targets = [it for it in items if self._can_explode_item(it)]
        if not targets:
            return []

        self.push_undo_snapshot()
        new_items = []
        for it in targets:
            obj = it.obj
            polys = self._path_to_polylines(obj.world_path())
            segments = []
            for pts in polys:
                for i in range(len(pts) - 1):
                    a, b = pts[i], pts[i + 1]
                    if (a - b).manhattanLength() < 1e-6:
                        continue
                    seg = QPainterPath()
                    seg.moveTo(a)
                    seg.lineTo(b)
                    child = self._world_path_to_svg_object(
                        seg, obj.layer_id, source_tag="segment"
                    )
                    if child is not None:
                        segments.append(child)
            if not segments:
                continue
            self.objects.remove(obj)
            self.scene_obj.removeItem(it)
            for child in segments:
                new_items.append(self.add_object(child))

        for it in new_items:
            it.setSelected(True)
        return new_items

    def _ensure_svg_path_object(self, item):
        """Convertit ShapeObject/TextObject en SvgPathObject pour l'édition de nœuds."""
        obj = item.obj
        if isinstance(obj, SvgPathObject):
            return item
        # Bake world path into a new SvgPathObject at same position
        world = obj.world_path()
        baked = self._world_path_to_svg_object(
            world, obj.layer_id, source_tag=getattr(obj, "kind", "path")
        )
        if baked is None:
            return None
        self.objects.remove(obj)
        self.scene_obj.removeItem(item)
        return self.add_object(baked)

    def enter_node_edit(self, item=None):
        """Active le mode nœuds sur l'item donné (ou la sélection unique)."""
        self.set_draw_tool(None)
        if item is None:
            selected = self.selected_items_vector()
            if len(selected) != 1:
                return False
            item = selected[0]
        item = self._ensure_svg_path_object(item)
        if item is None or not isinstance(item.obj, SvgPathObject):
            return False

        self.exit_node_edit()
        self._node_mode = True
        self._node_target_item = item
        self.scene_obj.clearSelection()
        item.setSelected(True)
        # Désactive le déplacement de l'objet pendant l'édition de nœuds
        item.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, False)
        self._rebuild_node_handles()
        self.setCursor(Qt.CursorShape.CrossCursor)
        return True

    def exit_node_edit(self):
        if self._node_target_item is not None:
            try:
                self._node_target_item.setFlag(
                    QGraphicsItem.GraphicsItemFlag.ItemIsMovable, True
                )
            except RuntimeError:
                pass
        self._clear_node_handles()
        self._node_mode = False
        self._node_target_item = None
        self._node_polylines = []
        self._node_drag_index = None
        self._node_drag_pushed_undo = False
        if not self._draw_tool:
            self.setCursor(Qt.CursorShape.ArrowCursor)

    def _clear_node_handles(self):
        for h in self._node_handles:
            try:
                self.scene_obj.removeItem(h)
            except RuntimeError:
                pass
        self._node_handles = []

    def _local_to_scene(self, local_pt: QPointF):
        """Point local objet (Y Qt descendant dans local_path) -> scène."""
        item = self._node_target_item
        if item is None:
            return local_pt
        s = self.px_per_mm
        # Même pipeline que VectorGraphicsItem.refresh : scale mm->px puis transform item
        p_px = QPointF(local_pt.x() * s, local_pt.y() * s)
        return item.mapToScene(p_px)

    def _scene_to_local(self, scene_pt: QPointF):
        item = self._node_target_item
        if item is None:
            return scene_pt
        s = self.px_per_mm
        p_item = item.mapFromScene(scene_pt)
        return QPointF(p_item.x() / s, p_item.y() / s)

    def _rebuild_node_handles(self):
        self._clear_node_handles()
        item = self._node_target_item
        if item is None or not isinstance(item.obj, SvgPathObject):
            return
        # Polylignes en coords locales (avec scale_x/y déjà appliqué via local_path)
        self._node_polylines = self._path_to_polylines(item.obj.local_path())
        s = self.px_per_mm
        handle_r = 4.0  # px écran approx — on utilise cosmetic via setScale inverse
        for pi, pts in enumerate(self._node_polylines):
            for vi, pt in enumerate(pts):
                scene_pt = self._local_to_scene(pt)
                # Taille constante à l'écran : rayon en coords scène selon zoom
                view_scale = max(self.transform().m11(), 0.01)
                r = 5.0 / view_scale
                handle = QGraphicsEllipseItem(scene_pt.x() - r, scene_pt.y() - r, 2 * r, 2 * r)
                handle.setBrush(QBrush(QColor("#ffcc00")))
                handle.setPen(QPen(QColor("#222222"), 0))
                handle.setZValue(2000)
                handle.setData(0, ("node", pi, vi))
                handle.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, False)
                handle.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, False)
                self.scene_obj.addItem(handle)
                self._node_handles.append(handle)

    def _apply_node_polylines_to_object(self):
        item = self._node_target_item
        if item is None or not isinstance(item.obj, SvgPathObject):
            return
        path = self._polylines_to_path(self._node_polylines)
        # Si scale_x/y != 1, local_path applique le scale : on stocke le path « non scalé »
        sx = getattr(item.obj, "scale_x", 1.0) or 1.0
        sy = getattr(item.obj, "scale_y", 1.0) or 1.0
        if abs(sx - 1.0) > 1e-9 or abs(sy - 1.0) > 1e-9:
            t = QTransform()
            t.scale(1.0 / sx, 1.0 / sy)
            path = t.map(path)
        item.obj._local_path_data = path
        item.refresh()
        self._rebuild_node_handles()

    def _hit_node_handle(self, scene_pos):
        view_scale = max(self.transform().m11(), 0.01)
        hit_r = 8.0 / view_scale
        best = None
        best_d = hit_r * hit_r
        for h in self._node_handles:
            data = h.data(0)
            if not data or data[0] != "node":
                continue
            c = h.rect().center()
            # rect is in item coords = scene for these items
            d = (c.x() - scene_pos.x()) ** 2 + (c.y() - scene_pos.y()) ** 2
            if d <= best_d:
                best_d = d
                best = (data[1], data[2])
        return best

    def _hit_segment(self, scene_pos):
        """Renvoie (poly_idx, insert_after_idx, local_point) si proche d'un segment."""
        if not self._node_polylines:
            return None
        view_scale = max(self.transform().m11(), 0.01)
        max_dist_scene = 8.0 / view_scale
        local_pos = self._scene_to_local(scene_pos)
        best = None
        best_d = max_dist_scene / max(self.px_per_mm, 1e-6)
        best_d = best_d * best_d
        for pi, pts in enumerate(self._node_polylines):
            for i in range(len(pts) - 1):
                a, b = pts[i], pts[i + 1]
                # Projection du point sur le segment
                abx, aby = b.x() - a.x(), b.y() - a.y()
                len2 = abx * abx + aby * aby
                if len2 < 1e-12:
                    continue
                t = ((local_pos.x() - a.x()) * abx + (local_pos.y() - a.y()) * aby) / len2
                t = max(0.0, min(1.0, t))
                proj = QPointF(a.x() + t * abx, a.y() + t * aby)
                dx, dy = local_pos.x() - proj.x(), local_pos.y() - proj.y()
                d = dx * dx + dy * dy
                if d < best_d:
                    best_d = d
                    best = (pi, i, proj)
        return best

    def delete_selected_node(self):
        """Supprime le nœud sous le curseur n'est pas disponible ici ; utilisé
        via sélection interne _node_drag_index ou dernier nœud cliqué."""
        if not self._node_mode or self._node_drag_index is None:
            return False
        pi, vi = self._node_drag_index
        if pi >= len(self._node_polylines):
            return False
        pts = self._node_polylines[pi]
        if len(pts) <= 2:
            # Trop peu de points : supprimer toute la polyligne
            self.push_undo_snapshot()
            self._node_polylines.pop(pi)
            if not self._node_polylines:
                # Plus rien : supprimer l'objet
                item = self._node_target_item
                self.exit_node_edit()
                if item is not None:
                    try:
                        self.objects.remove(item.obj)
                        self.scene_obj.removeItem(item)
                    except (ValueError, RuntimeError):
                        pass
                return True
            self._apply_node_polylines_to_object()
            return True
        self.push_undo_snapshot()
        pts.pop(vi)
        self._node_drag_index = None
        self._apply_node_polylines_to_object()
        return True

    def refresh_all(self):
        for item in self.scene_obj.items():
            if isinstance(item, VectorGraphicsItem):
                item.refresh()

    def selected_object(self):
        for item in self.scene_obj.selectedItems():
            if isinstance(item, VectorGraphicsItem):
                return item, item.obj
        return None, None
    def selected_items_vector(self):
        """Renvoie tous les éléments vectoriels actuellement sélectionnés."""
        return [
            item
            for item in self.scene_obj.selectedItems()
            if isinstance(item, VectorGraphicsItem)
    ]

    def _on_selection_changed(self):
        _, obj = self.selected_object()
        self.selection_changed.emit(obj)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.MiddleButton:
            self._pan_last_pos = None
            self.setCursor(
                Qt.CursorShape.CrossCursor if self._draw_tool else Qt.CursorShape.ArrowCursor
            )
            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton and self._node_mode:
            if self._node_drag_index is not None:
                self._rebuild_node_handles()
                self._node_drag_index = None
                self._node_drag_pushed_undo = False
            event.accept()
            return

        # Rectangle/ellipse : fin du TIRÉ de profondeur (relâchement)
        if (
            event.button() == Qt.MouseButton.LeftButton
            and self._draw_tool in ("rect", "ellipse")
            and self._draw_depth_dragging
            and self._draw_base_p1 is not None
            and self._draw_base_p2 is not None
        ):
            raw = self.mapToScene(event.position().toPoint())
            pt, _ = self._snap_scene_pos(raw)
            depth = self._depth_from_cursor(self._draw_base_p1, self._draw_base_p2, pt)
            obj = self._create_rect_from_base(
                self._draw_base_p1, self._draw_base_p2, depth,
                ellipse=(self._draw_tool == "ellipse"),
            )
            self._draw_depth_dragging = False
            self._cancel_draw_preview()
            if obj is not None:
                self.push_undo_snapshot()
                item = self.add_object(obj)
                self.scene_obj.clearSelection()
                item.setSelected(True)
            event.accept()
            return

        # Autres outils dessin/mesure : pas de finalisation sur release
        if (
            event.button() == Qt.MouseButton.LeftButton
            and self._draw_tool in ("line", "rect", "ellipse", "measure")
        ):
            event.accept()
            return

        if event.button() == Qt.MouseButton.LeftButton and self._group_drag_items:
            moved_items = list(self._group_drag_items)

            self._group_drag_items = []
            self._group_drag_last_scene_pos = None
            self._group_drag_anchor_item = None

            for item in moved_items:
                self.object_moved.emit(item.obj)

            event.accept()
            return

        super().mouseReleaseEvent(event)

    def _create_drawn_object(self, start_scene, end_scene):
        """Crée un ShapeObject (ligne / rect / ellipse) à partir de deux points scène."""
        x1, y1 = self.scene_to_mm(start_scene)
        x2, y2 = self.scene_to_mm(end_scene)
        layer_id = self._default_draw_layer_id()
        if not layer_id:
            return None

        if self._draw_tool == "line":
            dx, dy = x2 - x1, y2 - y1
            length = math.hypot(dx, dy)
            if length < 0.05:
                return None
            angle = math.degrees(math.atan2(dy, dx))
            return ShapeObject(
                shape_type="Ligne",
                width_mm=length,
                height_mm=0.1,
                layer_id=layer_id,
                x_mm=x1,
                y_mm=y1,
                rotation_deg=angle,
            )

        # Rectangle / ellipse : coin bas-gauche + largeur / hauteur positives
        left, right = (x1, x2) if x1 <= x2 else (x2, x1)
        bottom, top = (y1, y2) if y1 <= y2 else (y2, y1)
        w, h = right - left, top - bottom
        if w < 0.05 and h < 0.05:
            return None
        w = max(w, 0.05)
        h = max(h, 0.05)
        shape_type = "Ellipse" if self._draw_tool == "ellipse" else "Rectangle"
        return ShapeObject(
            shape_type=shape_type,
            width_mm=w,
            height_mm=h,
            layer_id=layer_id,
            x_mm=left,
            y_mm=bottom,
        )

    def _create_drawn_object_from_dims(self, start_scene, dims, direction_scene=None):
        """Crée une forme à partir du 1er point + dimensions clavier.

        Ligne : dims = (length_mm,) — direction = curseur ou horizontale.
        Rect/ellipse : dims = (width_mm, height_mm) — signe selon quadrant curseur.
        """
        x1, y1 = self.scene_to_mm(start_scene)
        layer_id = self._default_draw_layer_id()
        if not layer_id:
            return None

        if self._draw_tool == "line":
            length = float(dims[0])
            if length < 0.05:
                return None
            # Direction : vers le curseur si dispo, sinon +X
            if direction_scene is not None:
                x2, y2 = self.scene_to_mm(direction_scene)
                dx, dy = x2 - x1, y2 - y1
                norm = math.hypot(dx, dy)
                if norm < 1e-9:
                    dx, dy = 1.0, 0.0
                else:
                    dx, dy = dx / norm, dy / norm
            else:
                dx, dy = 1.0, 0.0
            angle = math.degrees(math.atan2(dy, dx))
            return ShapeObject(
                shape_type="Ligne",
                width_mm=length,
                height_mm=0.1,
                layer_id=layer_id,
                x_mm=x1,
                y_mm=y1,
                rotation_deg=angle,
            )

        if len(dims) < 2:
            return None
        w, h = abs(float(dims[0])), abs(float(dims[1]))
        if w < 0.05 and h < 0.05:
            return None
        w, h = max(w, 0.05), max(h, 0.05)
        # Quadrant selon le curseur par rapport au 1er point
        sx = sy = 1.0
        if direction_scene is not None:
            x2, y2 = self.scene_to_mm(direction_scene)
            if x2 < x1:
                sx = -1.0
            if y2 < y1:
                sy = -1.0
        left = x1 if sx >= 0 else x1 - w
        bottom = y1 if sy >= 0 else y1 - h
        shape_type = "Ellipse" if self._draw_tool == "ellipse" else "Rectangle"
        return ShapeObject(
            shape_type=shape_type,
            width_mm=w,
            height_mm=h,
            layer_id=layer_id,
            x_mm=left,
            y_mm=bottom,
        )

    def _parse_draw_dimensions(self, text):
        """Parse '25', '25mm', '30x20', '30 x 20', '30,20' → tuple de floats (mm)."""
        t = (text or "").strip().lower().replace(",", "x").replace(" ", "")
        t = t.replace("mm", "")
        if not t:
            return None
        if "x" in t:
            parts = [p for p in t.split("x") if p]
            try:
                vals = tuple(float(p) for p in parts[:2])
            except ValueError:
                return None
            return vals if vals else None
        try:
            return (float(t),)
        except ValueError:
            return None

    def _commit_draw_dimensions(self):
        """Valide le buffer de dimensions et crée l'objet."""
        dims = self._parse_draw_dimensions(self._draw_dim_buffer)
        if not dims:
            return False

        # Profondeur seule après base 2 nœuds (rect / ellipse)
        if (
            self._draw_awaiting_depth
            and self._draw_base_p1 is not None
            and self._draw_base_p2 is not None
            and self._draw_tool in ("rect", "ellipse")
        ):
            depth = float(dims[0])
            # Signe : côté du curseur par rapport à la base
            if self._draw_last_cursor_scene is not None:
                auto = self._depth_from_cursor(
                    self._draw_base_p1, self._draw_base_p2, self._draw_last_cursor_scene
                )
                if auto < 0:
                    depth = -abs(depth)
                else:
                    depth = abs(depth)
            obj = self._create_rect_from_base(
                self._draw_base_p1, self._draw_base_p2, depth,
                ellipse=(self._draw_tool == "ellipse"),
            )
            self._cancel_draw_preview()
            if obj is None:
                return False
            self.push_undo_snapshot()
            item = self.add_object(obj)
            self.scene_obj.clearSelection()
            item.setSelected(True)
            return True

        if not self._draw_awaiting_second or self._draw_start_scene is None:
            return False
        if self._draw_tool == "line" and len(dims) >= 1:
            pass
        elif self._draw_tool in ("rect", "ellipse") and len(dims) >= 2:
            pass
        elif self._draw_tool in ("rect", "ellipse") and len(dims) == 1:
            dims = (dims[0], dims[0])  # carré / cercle
        else:
            return False
        obj = self._create_drawn_object_from_dims(
            self._draw_start_scene, dims, self._draw_last_cursor_scene
        )
        self._cancel_draw_preview()
        if obj is None:
            return False
        self.push_undo_snapshot()
        item = self.add_object(obj)
        self.scene_obj.clearSelection()
        item.setSelected(True)
        return True

    def _depth_from_cursor(self, p1_scene, p2_scene, cursor_scene):
        """Distance signée du curseur à la droite p1→p2, en mm (Y machine)."""
        x1, y1 = self.scene_to_mm(p1_scene)
        x2, y2 = self.scene_to_mm(p2_scene)
        cx, cy = self.scene_to_mm(cursor_scene)
        dx, dy = x2 - x1, y2 - y1
        length = math.hypot(dx, dy)
        if length < 1e-9:
            return 0.0
        # Normale unitaire à gauche de p1→p2 : (-dy, dx) / length
        nx, ny = -dy / length, dx / length
        # Projection du vecteur p1→cursor sur la normale
        return (cx - x1) * nx + (cy - y1) * ny

    def _preview_path_base_depth(self, p1_scene, p2_scene, depth_mm, ellipse=False):
        """Aperçu scène d'un rectangle (ou ellipse) défini par base + profondeur."""
        x1, y1 = self.scene_to_mm(p1_scene)
        x2, y2 = self.scene_to_mm(p2_scene)
        dx, dy = x2 - x1, y2 - y1
        length = math.hypot(dx, dy)
        if length < 1e-9:
            return QPainterPath()
        ux, uy = dx / length, dy / length
        nx, ny = -uy, ux  # normale
        # 4 coins en mm monde
        c0 = (x1, y1)
        c1 = (x2, y2)
        c2 = (x2 + nx * depth_mm, y2 + ny * depth_mm)
        c3 = (x1 + nx * depth_mm, y1 + ny * depth_mm)
        s0 = self.mm_to_scene(*c0)
        s1 = self.mm_to_scene(*c1)
        s2 = self.mm_to_scene(*c2)
        s3 = self.mm_to_scene(*c3)
        path = QPainterPath()
        if ellipse:
            # Approximation : bounding orienté via polygone
            path.moveTo(s0)
            path.lineTo(s1)
            path.lineTo(s2)
            path.lineTo(s3)
            path.closeSubpath()
        else:
            path.moveTo(s0)
            path.lineTo(s1)
            path.lineTo(s2)
            path.lineTo(s3)
            path.closeSubpath()
        return path

    def _create_rect_from_base(self, p1_scene, p2_scene, depth_mm, ellipse=False):
        """Rectangle/ellipse : largeur = |p1p2|, hauteur = |depth|, orientation = angle p1→p2."""
        x1, y1 = self.scene_to_mm(p1_scene)
        x2, y2 = self.scene_to_mm(p2_scene)
        dx, dy = x2 - x1, y2 - y1
        width = math.hypot(dx, dy)
        # Refuse les « rectangles plats » (souvent un 3e clic trop proche de la base)
        if width < 0.05 or abs(depth_mm) < 0.2:
            return None
        layer_id = self._default_draw_layer_id()
        if not layer_id:
            return None
        angle = math.degrees(math.atan2(dy, dx))
        height = abs(depth_mm)
        # Toujours ancrer l'origine (x_mm,y_mm) sur le 1er point p1.
        # Si la profondeur est de l'autre côté de la normale, on inverse le
        # sens local via mirror_v pour que le corps du rectangle suive l'aperçu
        # tout en gardant p1 comme point d'ancrage (1er point).
        mirror_v = False
        if depth_mm < 0:
            mirror_v = True
        shape_type = "Ellipse" if ellipse else "Rectangle"
        return ShapeObject(
            shape_type=shape_type,
            width_mm=width,
            height_mm=height,
            layer_id=layer_id,
            x_mm=x1,
            y_mm=y1,
            rotation_deg=angle,
            mirror_v=mirror_v,
        )

    def _finalize_measure(self, p1_scene, p2_scene):
        """Ajoute une annotation de mesure (distance + ΔX / ΔY) sur le canevas."""
        from PyQt6.QtWidgets import QGraphicsSimpleTextItem

        x1, y1 = self.scene_to_mm(p1_scene)
        x2, y2 = self.scene_to_mm(p2_scene)
        dist = math.hypot(x2 - x1, y2 - y1)
        dx, dy = x2 - x1, y2 - y1
        label = f"{dist:.2f} mm"
        if abs(dx) > 0.01 or abs(dy) > 0.01:
            label += f"  (ΔX {dx:+.2f}  ΔY {dy:+.2f})"

        path = QPainterPath()
        path.moveTo(p1_scene)
        path.lineTo(p2_scene)
        pen = QPen(QColor("#ffaa00"), 1.2, Qt.PenStyle.DashLine)
        pen.setCosmetic(True)
        line_item = self.scene_obj.addPath(path, pen)
        line_item.setZValue(1500)

        mid = QPointF((p1_scene.x() + p2_scene.x()) / 2, (p1_scene.y() + p2_scene.y()) / 2)
        text_item = QGraphicsSimpleTextItem(label)
        text_item.setBrush(QBrush(QColor("#ffcc66")))
        text_item.setPos(mid.x() + 4, mid.y() - 16)
        text_item.setZValue(1501)
        # Échelle texte approximativement constante à l'écran
        view_scale = max(abs(self.transform().m11()), 0.01)
        text_item.setScale(1.0 / view_scale)
        self.scene_obj.addItem(text_item)
        self._measure_labels.extend([line_item, text_item])

    def mouseDoubleClickEvent(self, event):
        if self._node_mode and event.button() == Qt.MouseButton.LeftButton:
            scene_pos = self.mapToScene(event.position().toPoint())
            # Priorité : pas sur un nœud existant
            if self._hit_node_handle(scene_pos) is None:
                hit = self._hit_segment(scene_pos)
                if hit is not None:
                    pi, after_i, proj = hit
                    self.push_undo_snapshot()
                    self._node_polylines[pi].insert(after_i + 1, proj)
                    self._apply_node_polylines_to_object()
                    event.accept()
                    return
        super().mouseDoubleClickEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape and self._draw_tool:
            if self._draw_phase is not None or self._draw_awaiting_depth or self._draw_awaiting_second:
                self._cancel_draw_preview()
                event.accept()
                return
            if self._draw_tool == "measure" and self._measure_p1 is not None:
                self._clear_measure_temp()
                event.accept()
                return
            self.set_draw_tool(None)
            event.accept()
            return
        if event.key() == Qt.Key.Key_Escape and self._node_mode:
            self.exit_node_edit()
            event.accept()
            return

        # Saisie de dimensions après le 1er point ou profondeur après base
        if (
            (self._draw_awaiting_second or self._draw_awaiting_depth)
            and self._draw_tool in ("line", "rect", "ellipse")
        ):
            key = event.key()
            text = event.text() or ""
            if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                if self._commit_draw_dimensions():
                    event.accept()
                    return
            if key == Qt.Key.Key_Backspace:
                self._draw_dim_buffer = self._draw_dim_buffer[:-1]
                event.accept()
                return
            if text and (text.isdigit() or text in ".,xX*-+"):
                if text in "X*":
                    text = "x"
                if text == ",":
                    text = "."
                self._draw_dim_buffer += text
                event.accept()
                return

        if self._node_mode and event.key() in (
            Qt.Key.Key_Delete, Qt.Key.Key_Backspace
        ):
            # Supprime le nœud le plus récemment dragué, ou celui sous le curseur
            if self._node_drag_index is not None:
                self.delete_selected_node()
            else:
                # Essaye le nœud sous la position courante de la souris
                from PyQt6.QtGui import QCursor
                scene_pos = self.mapToScene(self.mapFromGlobal(QCursor.pos()))
                hit = self._hit_node_handle(scene_pos)
                if hit is not None:
                    self._node_drag_index = hit
                    self.delete_selected_node()
            event.accept()
            return
        if event.matches(QKeySequence.StandardKey.SelectAll):
            for item in self.scene_obj.items():
                if isinstance(item, VectorGraphicsItem):
                    item.setSelected(True)
            event.accept()
            return
        if event.matches(QKeySequence.StandardKey.Undo):
            self.undo()
            event.accept()
            return
        if event.matches(QKeySequence.StandardKey.Redo):
            self.redo()
            event.accept()
            return
        if event.matches(QKeySequence.StandardKey.Copy):
            self.copy_selected()
            event.accept()
            return
        if event.matches(QKeySequence.StandardKey.Paste):
            self.paste_clipboard()
            event.accept()
            return
        if event.key() == Qt.Key.Key_G and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            self.group_selected()
            event.accept()
            return
        if event.key() == Qt.Key.Key_D and (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            self.duplicate_selected()
            event.accept()
            return
        if event.key() in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.remove_selected()
            event.accept()
            return
        arrows = {Qt.Key.Key_Left: (-1, 0), Qt.Key.Key_Right: (1, 0), Qt.Key.Key_Up: (0, 1), Qt.Key.Key_Down: (0, -1)}
        if event.key() in arrows:
            direction = arrows[event.key()]
            if self.nudge_selection(direction[0], direction[1], event.modifiers()):
                event.accept()
                return
        super().keyPressEvent(event)

    def nudge_selection(self, dir_x, dir_y, modifiers=None):
        """Flèches du clavier : déplace la sélection de 1 mm (Maj : 10 mm ; Alt : 0,1 mm). Les pressions
        rapprochées (touche maintenue) ne comptent que pour UN « Annuler ». Renvoie False si rien n'est
        sélectionné : la vue défile alors normalement."""
        items = [it for it in self.scene_obj.selectedItems() if isinstance(it, VectorGraphicsItem)]
        if not items:
            return False
        shift = bool(modifiers and (modifiers & Qt.KeyboardModifier.ShiftModifier))
        alt = bool(modifiers and (modifiers & Qt.KeyboardModifier.AltModifier))
        step = nudge_step(shift=shift, alt=alt)
        now = time.monotonic()
        if now - getattr(self, "_last_nudge_time", -1e9) > NUDGE_UNDO_WINDOW_S:
            self.push_undo_snapshot()
        self._last_nudge_time = now
        for item in items:
            item.obj.x_mm += dir_x * step
            item.obj.y_mm += dir_y * step
            item.refresh()
        return True

    def copy_selected(self):
        """Ctrl+C : copie les objets sélectionnés dans un presse-papiers
        interne (propre à l'éditeur, pas le presse-papiers système)."""
        selected = [it.obj for it in self.scene_obj.selectedItems() if isinstance(it, VectorGraphicsItem)]
        if selected:
            self._clipboard = [o.to_dict() for o in selected]

    def paste_clipboard(self):
        """Ctrl+V : colle les objets copiés, légèrement décalés pour rester
        visibles distinctement de l'original."""
        if not getattr(self, "_clipboard", None):
            return
        self.push_undo_snapshot()
        for item in list(self.scene_obj.selectedItems()):
            item.setSelected(False)
        for d in self._clipboard:
            try:
                clone = VectorObject.from_dict(d)
            except Exception:
                continue
            clone.id = uuid.uuid4().hex[:8]
            clone.x_mm += 5
            clone.y_mm += 5
            new_item = self.add_object(clone)
            new_item.setSelected(True)

    def push_undo_snapshot(self):
        """À appeler AVANT toute action qui modifie les objets (ajout,
        suppression, déplacement, redimensionnement...), pour pouvoir revenir
        en arrière avec Ctrl+Z ou le bouton Annuler."""
        try:
            snapshot = [o.to_dict() for o in self.objects]
        except Exception:
            return
        self._undo_stack.append(snapshot)
        if len(self._undo_stack) > self._max_undo:
            self._undo_stack.pop(0)
        # Toute nouvelle action invalide le futur "refaire" (comportement
        # standard undo/redo : impossible de "refaire" une branche qu'une
        # nouvelle action vient de remplacer).
        self._redo_stack.clear()

    def _current_snapshot(self):
        return [o.to_dict() for o in self.objects]

    def _restore_snapshot(self, snapshot):
        for item in list(self.scene_obj.items()):
            if isinstance(item, VectorGraphicsItem):
                self.scene_obj.removeItem(item)
        self.objects = []
        for d in snapshot:
            try:
                self.add_object(VectorObject.from_dict(d))
            except Exception:
                continue

    def undo(self):
        if not self._undo_stack:
            return
        current = self._current_snapshot()
        snapshot = self._undo_stack.pop()
        self._redo_stack.append(current)
        if len(self._redo_stack) > self._max_undo:
            self._redo_stack.pop(0)
        self._restore_snapshot(snapshot)

    def redo(self):
        """Ctrl+Y (ou Ctrl+Maj+Z selon la plateforme, via
        QKeySequence.StandardKey.Redo) : rétablit la dernière action annulée
        par undo()."""
        if not self._redo_stack:
            return
        current = self._current_snapshot()
        snapshot = self._redo_stack.pop()
        self._undo_stack.append(current)
        if len(self._undo_stack) > self._max_undo:
            self._undo_stack.pop(0)
        self._restore_snapshot(snapshot)

    def contextMenuEvent(self, event):
        """Clic droit : assigner un calque (découpe/gravure) ou redimensionner
        toute la sélection courante en une seule action — fonctionne aussi
        bien sur un seul objet que sur plusieurs (Ctrl+A ou rubber-band)."""
        selected = [it for it in self.scene_obj.selectedItems() if isinstance(it, VectorGraphicsItem)]
        if not selected:
            item_at = self.itemAt(event.pos())
            if isinstance(item_at, VectorGraphicsItem):
                item_at.setSelected(True)
                selected = [item_at]
        if not selected:
            return

        menu = QMenu(self)
        n = len(selected)
        label_suffix = tr("vector.n_objects").format(n=n) if n > 1 else ""

        layer_menu = menu.addMenu(tr("vector.assign_to_layer") + label_suffix)
        for layer in self.layer_manager.layers:
            action = layer_menu.addAction(f"{layer.name}  [{layer.mode}]")
            action.triggered.connect(lambda checked=False, lid=layer.id, items=selected: self._bulk_assign_layer(items, lid))

        resize_action = menu.addAction(tr("vector.resize_ellipsis") + label_suffix)
        resize_action.triggered.connect(lambda: self._bulk_resize(selected))

        if n >= 2:
            group_action = menu.addAction(tr("vector.group_objects").format(n=n))
            group_action.triggered.connect(self.group_selected)

        ungroupable = [it for it in selected if self._can_ungroup_item(it)]
        if ungroupable:
            ungroup_action = menu.addAction(tr("vector.ungroup_objects"))
            ungroup_action.triggered.connect(self.ungroup_selected)

        explodable = [it for it in selected if self._can_explode_item(it)]
        if explodable:
            explode_action = menu.addAction(tr("vector.explode_path"))
            explode_action.triggered.connect(self.explode_selected)

        if len(selected) == 1:
            nodes_action = menu.addAction(tr("vector.edit_nodes"))
            nodes_action.triggered.connect(lambda: self.enter_node_edit(selected[0]))

        if self._node_mode:
            menu.addSeparator()
            exit_nodes = menu.addAction(tr("vector.exit_nodes"))
            exit_nodes.triggered.connect(self.exit_node_edit)
            del_node = menu.addAction(tr("vector.delete_node"))
            del_node.triggered.connect(self.delete_selected_node)

        menu.addSeparator()
        rotate_action = menu.addAction(tr("ui.vector_rotate_90"))
        rotate_action.triggered.connect(lambda: self._bulk_rotate(selected))
        dup_action = menu.addAction(tr("ui.vector_duplicate"))
        dup_action.triggered.connect(self.duplicate_selected)
        del_action = menu.addAction(tr("ui.vector_delete"))
        del_action.triggered.connect(self.remove_selected)

        menu.exec(event.globalPos())

    def _bulk_assign_layer(self, items, layer_id):
        self.push_undo_snapshot()
        for it in items:
            it.obj.layer_id = layer_id
            it.refresh()

    def _bulk_resize(self, items):
        """Redimensionne toute la sélection COMME UN GROUPE : les proportions
        et positions relatives entre les objets sont conservées (comme un
        redimensionnement de groupe dans un éditeur vectoriel classique),
        en millimètres plutôt qu'en pourcentage abstrait."""
        boxes = [it.obj.world_path().boundingRect() for it in items]
        x_min = min(b.left() for b in boxes)
        x_max = max(b.right() for b in boxes)
        y_min = min(b.top() for b in boxes)
        y_max = max(b.bottom() for b in boxes)
        current_w = max(x_max - x_min, 1e-6)
        current_h = max(y_max - y_min, 1e-6)

        dialog = QDialog(self)
        dialog.setWindowTitle(tr("vector.dlg.resize_title"))
        layout = QFormLayout(dialog)
        layout.addRow(QLabel(tr("vector.dlg.group_size").format(w=current_w, h=current_h)))

        chk_keep_ratio = QCheckBox(tr("vector.dlg.keep_ratio"))
        chk_keep_ratio.setChecked(True)
        layout.addRow("", chk_keep_ratio)

        spin_w = QDoubleSpinBox(); spin_w.setRange(0.1, 5000.0); spin_w.setDecimals(2)
        spin_w.setValue(current_w); spin_w.setSuffix(" mm")
        spin_h = QDoubleSpinBox(); spin_h.setRange(0.1, 5000.0); spin_h.setDecimals(2)
        spin_h.setValue(current_h); spin_h.setSuffix(" mm")
        layout.addRow(tr("vector.dlg.new_width"), spin_w)
        layout.addRow(tr("vector.dlg.new_height"), spin_h)

        ratio = current_w / current_h if current_h else 1.0
        state = {"updating": False}

        def on_w_changed(val):
            if state["updating"] or not chk_keep_ratio.isChecked():
                return
            state["updating"] = True
            spin_h.setValue(val / ratio if ratio else val)
            state["updating"] = False

        def on_h_changed(val):
            if state["updating"] or not chk_keep_ratio.isChecked():
                return
            state["updating"] = True
            spin_w.setValue(val * ratio)
            state["updating"] = False

        spin_w.valueChanged.connect(on_w_changed)
        spin_h.valueChanged.connect(on_h_changed)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addRow(buttons)

        if not dialog.exec():
            return

        self.push_undo_snapshot()
        factor_x = spin_w.value() / current_w
        factor_y = spin_h.value() / current_h

        for it in items:
            obj = it.obj
            # Repositionne l'objet proportionnellement à l'intérieur du groupe
            # (mise à l'échelle autour du coin bas-gauche du groupe entier).
            obj.x_mm = x_min + (obj.x_mm - x_min) * factor_x
            obj.y_mm = y_min + (obj.y_mm - y_min) * factor_y
            if isinstance(obj, ShapeObject):
                obj.width_mm *= factor_x
                obj.height_mm *= factor_y
            elif isinstance(obj, TextObject):
                obj.size_mm *= factor_y
                obj.letter_spacing_mm *= factor_x
            elif isinstance(obj, SvgPathObject):
                obj.scale_x = getattr(obj, "scale_x", 1.0) * factor_x
                obj.scale_y = getattr(obj, "scale_y", 1.0) * factor_y
            it.refresh()

    def _bulk_rotate(self, items):
        self.push_undo_snapshot()
        for it in items:
            it.obj.rotation_deg = (it.obj.rotation_deg + 90.0) % 360.0
            it.refresh()

    def set_object_position(self, obj: VectorObject, x_mm, y_mm, rotation_deg=None):
        """Positionnement précis par saisie numérique (offset X/Y en mm depuis
        l'origine de la zone de travail), utilisé par le panneau de propriétés."""
        obj.x_mm = x_mm
        obj.y_mm = y_mm
        if rotation_deg is not None:
            obj.rotation_deg = rotation_deg
        for item in self.scene_obj.items():
            if isinstance(item, VectorGraphicsItem) and item.obj is obj:
                item.refresh()
                break

    # -- (dé)sérialisation ----------------------------------------------------
    def serialize_objects(self):
        return [o.to_dict() for o in self.objects]

    def load_objects(self, data):
        for item in list(self.scene_obj.items()):
            if isinstance(item, VectorGraphicsItem):
                self.scene_obj.removeItem(item)
        self.objects = []
        for d in (data or []):
            self.add_object(VectorObject.from_dict(d))


# ============================================================================
# 4) BOITES DE DIALOGUE : INSERTION DE TEXTE / FORME
# ============================================================================

class TextInsertDialog(QDialog):
    """Boîte de dialogue façon LightBurn pour insérer/éditer un objet texte."""

    def __init__(self, layer_manager: LayerManager, text_obj: TextObject = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("vector.dlg.text_title_new") if text_obj is None else tr("vector.dlg.text_title_edit"))
        self.layer_manager = layer_manager
        self.editing = text_obj

        layout = QFormLayout(self)

        self.edit_text = QLineEdit(text_obj.text if text_obj else tr("vector.dlg.text_default"))
        layout.addRow(tr("vector.dlg.text_label"), self.edit_text)

        self.combo_font = QFontComboBox()
        if text_obj:
            self.combo_font.setCurrentFont(QFont(text_obj.font_family))
        layout.addRow(tr("vector.dlg.font"), self.combo_font)

        style_row = QHBoxLayout()
        self.chk_bold = QCheckBox(tr("vector.dlg.bold")); self.chk_bold.setChecked(bool(text_obj and text_obj.bold))
        self.chk_italic = QCheckBox(tr("vector.dlg.italic")); self.chk_italic.setChecked(bool(text_obj and text_obj.italic))
        style_row.addWidget(self.chk_bold); style_row.addWidget(self.chk_italic)
        layout.addRow(tr("vector.dlg.style"), style_row)

        self.spin_size = QDoubleSpinBox(); self.spin_size.setRange(1.0, 500.0)
        self.spin_size.setValue(text_obj.size_mm if text_obj else 10.0)
        self.spin_size.setSuffix(" mm")
        layout.addRow(tr("vector.dlg.size_height"), self.spin_size)

        self.spin_spacing = QDoubleSpinBox(); self.spin_spacing.setRange(-5.0, 50.0)
        self.spin_spacing.setValue(text_obj.letter_spacing_mm if text_obj else 0.0)
        self.spin_spacing.setSuffix(" mm")
        layout.addRow(tr("vector.dlg.letter_spacing"), self.spin_spacing)

        orient_row = QHBoxLayout()
        self.rb_horizontal = QRadioButton(tr("vector.dlg.horizontal"))
        self.rb_vertical = QRadioButton(tr("vector.dlg.vertical"))
        (self.rb_vertical if (text_obj and text_obj.vertical) else self.rb_horizontal).setChecked(True)
        grp = QButtonGroup(self); grp.addButton(self.rb_horizontal); grp.addButton(self.rb_vertical)
        orient_row.addWidget(self.rb_horizontal); orient_row.addWidget(self.rb_vertical)
        layout.addRow(tr("vector.dlg.orientation"), orient_row)

        mirror_row = QHBoxLayout()
        self.chk_mirror_h = QCheckBox(tr("img.mirror_h"))
        self.chk_mirror_h.setChecked(bool(text_obj and text_obj.mirror_h))
        self.chk_mirror_v = QCheckBox(tr("img.mirror_v"))
        self.chk_mirror_v.setChecked(bool(text_obj and text_obj.mirror_v))
        mirror_row.addWidget(self.chk_mirror_h); mirror_row.addWidget(self.chk_mirror_v)
        layout.addRow(tr("vector.dlg.mirror"), mirror_row)

        self.combo_layer = QComboBox()
        for l in self.layer_manager.layers:
            self.combo_layer.addItem(f"{l.name}  [{l.mode}]", l.id)
        if text_obj and text_obj.layer_id:
            idx = self.combo_layer.findData(text_obj.layer_id)
            if idx >= 0:
                self.combo_layer.setCurrentIndex(idx)
        layout.addRow(tr("ui.vector_layer"), self.combo_layer)

        pos_row = QHBoxLayout()
        self.spin_x = QDoubleSpinBox(); self.spin_x.setRange(-1000.0, 1000.0)
        self.spin_x.setDecimals(2); self.spin_x.setSuffix(" mm")
        self.spin_x.setValue(text_obj.x_mm if text_obj else 10.0)
        self.spin_y = QDoubleSpinBox(); self.spin_y.setRange(-1000.0, 1000.0)
        self.spin_y.setDecimals(2); self.spin_y.setSuffix(" mm")
        self.spin_y.setValue(text_obj.y_mm if text_obj else 10.0)
        pos_row.addWidget(QLabel("X :")); pos_row.addWidget(self.spin_x)
        pos_row.addWidget(QLabel("Y :")); pos_row.addWidget(self.spin_y)
        layout.addRow(tr("vector.dlg.corner_pos"), pos_row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def get_object(self) -> TextObject:
        layer_id = self.combo_layer.currentData()
        if self.editing:
            obj = self.editing
        else:
            obj = TextObject(layer_id=layer_id, x_mm=10.0, y_mm=10.0)
        obj.text = self.edit_text.text() or "TEXTE"
        obj.font_family = self.combo_font.currentFont().family()
        obj.bold = self.chk_bold.isChecked()
        obj.italic = self.chk_italic.isChecked()
        obj.size_mm = self.spin_size.value()
        obj.letter_spacing_mm = self.spin_spacing.value()
        obj.vertical = self.rb_vertical.isChecked()
        obj.mirror_h = self.chk_mirror_h.isChecked()
        obj.mirror_v = self.chk_mirror_v.isChecked()
        obj.layer_id = layer_id
        obj.x_mm = self.spin_x.value()
        obj.y_mm = self.spin_y.value()
        return obj


class AssignLayerDialog(QDialog):
    """Boîte de dialogue pour un objet importé depuis un SVG : calque, et
    redimensionnement (largeur/hauteur en mm, avec conservation du ratio en
    option). Sa géométrie de base reste fixe — seuls son échelle, son calque,
    sa position et sa rotation sont modifiables (position/rotation via le
    panneau dédié de l'éditeur vectoriel)."""

    def __init__(self, layer_manager: LayerManager, svg_obj=None, current_layer_id=None,
                 title="Propriétés de l'élément SVG", parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.svg_obj = svg_obj
        layout = QFormLayout(self)

        self.combo_layer = QComboBox()
        for l in layer_manager.layers:
            self.combo_layer.addItem(f"{l.name}  [{l.mode}]", l.id)
        lid = current_layer_id if current_layer_id is not None else (svg_obj.layer_id if svg_obj else None)
        if lid:
            idx = self.combo_layer.findData(lid)
            if idx >= 0:
                self.combo_layer.setCurrentIndex(idx)
        layout.addRow(tr("ui.vector_layer"), self.combo_layer)

        self.spin_w = None
        self.spin_h = None
        self._updating = False
        if svg_obj is not None:
            orig_bbox = svg_obj._local_path_data.boundingRect()
            self._orig_w = max(orig_bbox.width(), 1e-6)
            self._orig_h = max(orig_bbox.height(), 1e-6)
            cur_w = self._orig_w * getattr(svg_obj, "scale_x", 1.0)
            cur_h = self._orig_h * getattr(svg_obj, "scale_y", 1.0)
            self._ratio = cur_w / cur_h if cur_h > 0 else 1.0

            self.chk_keep_ratio = QCheckBox(tr("vector.dlg.keep_ratio"))
            self.chk_keep_ratio.setChecked(True)
            layout.addRow("", self.chk_keep_ratio)

            self.spin_w = QDoubleSpinBox(); self.spin_w.setRange(0.1, 5000.0); self.spin_w.setDecimals(2)
            self.spin_w.setValue(cur_w); self.spin_w.setSuffix(" mm")
            self.spin_h = QDoubleSpinBox(); self.spin_h.setRange(0.1, 5000.0); self.spin_h.setDecimals(2)
            self.spin_h.setValue(cur_h); self.spin_h.setSuffix(" mm")
            self.spin_w.valueChanged.connect(self._on_w_changed)
            self.spin_h.valueChanged.connect(self._on_h_changed)
            layout.addRow(tr("vector.dlg.width"), self.spin_w)
            layout.addRow(tr("vector.dlg.height"), self.spin_h)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def _on_w_changed(self, val):
        if self._updating or not self.chk_keep_ratio.isChecked():
            return
        self._updating = True
        if self._ratio:
            self.spin_h.setValue(val / self._ratio)
        self._updating = False

    def _on_h_changed(self, val):
        if self._updating or not self.chk_keep_ratio.isChecked():
            return
        self._updating = True
        self.spin_w.setValue(val * self._ratio)
        self._updating = False

    def selected_layer_id(self):
        return self.combo_layer.currentData()

    def apply_to(self, svg_obj):
        """Applique le calque choisi et, si applicable, la nouvelle taille."""
        svg_obj.layer_id = self.selected_layer_id()
        if self.spin_w is not None:
            svg_obj.scale_x = self.spin_w.value() / self._orig_w
            svg_obj.scale_y = self.spin_h.value() / self._orig_h


class ShapeInsertDialog(QDialog):
    """Boîte de dialogue pour insérer OU modifier une forme géométrique."""

    def __init__(self, layer_manager: LayerManager, shape_obj: "ShapeObject" = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("vector.dlg.shape_title_new") if shape_obj is None else tr("vector.dlg.shape_title_edit"))
        self.layer_manager = layer_manager
        self.editing = shape_obj

        layout = QFormLayout(self)

        self.combo_type = QComboBox()
        self.combo_type.addItems(ShapeObject.SHAPE_TYPES)
        if shape_obj:
            self.combo_type.setCurrentText(shape_obj.shape_type)
        layout.addRow(tr("vector.dlg.shape_type"), self.combo_type)

        self.spin_w = QDoubleSpinBox(); self.spin_w.setRange(0.5, 1000.0)
        self.spin_w.setValue(shape_obj.width_mm if shape_obj else 20.0); self.spin_w.setSuffix(" mm")
        self.spin_h = QDoubleSpinBox(); self.spin_h.setRange(0.5, 1000.0)
        self.spin_h.setValue(shape_obj.height_mm if shape_obj else 15.0); self.spin_h.setSuffix(" mm")
        layout.addRow(tr("vector.dlg.width"), self.spin_w)
        layout.addRow(tr("vector.dlg.height"), self.spin_h)

        self.spin_sides = QSpinBox(); self.spin_sides.setRange(3, 24)
        self.spin_sides.setValue(shape_obj.sides if shape_obj else 6)
        layout.addRow(tr("vector.dlg.sides"), self.spin_sides)

        self.combo_layer = QComboBox()
        for l in self.layer_manager.layers:
            self.combo_layer.addItem(f"{l.name}  [{l.mode}]", l.id)
        if shape_obj and shape_obj.layer_id:
            idx = self.combo_layer.findData(shape_obj.layer_id)
            if idx >= 0:
                self.combo_layer.setCurrentIndex(idx)
        layout.addRow(tr("ui.vector_layer"), self.combo_layer)

        pos_row = QHBoxLayout()
        self.spin_x = QDoubleSpinBox(); self.spin_x.setRange(-1000.0, 1000.0)
        self.spin_x.setDecimals(2); self.spin_x.setSuffix(" mm")
        self.spin_x.setValue(shape_obj.x_mm if shape_obj else 10.0)
        self.spin_y = QDoubleSpinBox(); self.spin_y.setRange(-1000.0, 1000.0)
        self.spin_y.setDecimals(2); self.spin_y.setSuffix(" mm")
        self.spin_y.setValue(shape_obj.y_mm if shape_obj else 10.0)
        pos_row.addWidget(QLabel("X :")); pos_row.addWidget(self.spin_x)
        pos_row.addWidget(QLabel("Y :")); pos_row.addWidget(self.spin_y)
        layout.addRow(tr("vector.dlg.corner_pos"), pos_row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def get_object(self) -> ShapeObject:
        layer_id = self.combo_layer.currentData()
        if self.editing:
            obj = self.editing
        else:
            obj = ShapeObject(layer_id=layer_id)
        obj.shape_type = self.combo_type.currentText()
        obj.width_mm = self.spin_w.value()
        obj.height_mm = self.spin_h.value()
        obj.sides = self.spin_sides.value()
        obj.layer_id = layer_id
        obj.x_mm = self.spin_x.value()
        obj.y_mm = self.spin_y.value()
        return obj


# ============================================================================
# 5) EXTRACTION GEOMETRIQUE (thread-safe) + GENERATION G-CODE PAR CALQUE
# ============================================================================

def _optimize_polygon_order(polygons):
    """Réordonne une liste de polygones par plus proche voisin (glouton) en
    partant du premier tracé : à chaque étape, choisit le polygone restant
    dont le point de départ est le plus proche du dernier point du tracé
    précédent. Ne change JAMAIS la géométrie elle-même, seulement l'ordre
    de passage — réduit les déplacements G0 entre les tracés d'un même
    calque (Découpe/Marquage), qui suivaient sinon l'ordre de création/
    import des objets, souvent loin d'être optimal.

    Plafonné en pratique par l'appelant (voir extract_vector_layer_data) :
    algorithme glouton en O(n²), appelé dans le thread principal Qt — pas
    de coût significatif pour un nombre raisonnable de tracés, mais à
    éviter sur des milliers d'objets."""
    if len(polygons) < 2:
        return polygons
    remaining = list(polygons)
    ordered = [remaining.pop(0)]
    current_end = ordered[-1][-1]
    while remaining:
        best_idx = min(
            range(len(remaining)),
            key=lambda i: (remaining[i][0][0] - current_end[0]) ** 2
                        + (remaining[i][0][1] - current_end[1]) ** 2
        )
        nxt = remaining.pop(best_idx)
        ordered.append(nxt)
        current_end = nxt[-1]
    return ordered


# Au-delà de ce nombre de tracés dans un même calque, l'optimisation
# glouton (O(n²)) est sautée pour ce calque — évite de bloquer l'UI
# plusieurs secondes sur un design très complexe (des milliers d'objets),
# puisque extract_vector_layer_data s'exécute dans le thread principal Qt.
MAX_POLYGONS_FOR_PATH_OPTIMIZATION = 1500


def extract_vector_layer_data(objects, layer_manager: LayerManager, optimize_path=True):
    """À appeler dans le thread principal (Qt). Convertit chaque VectorObject en
    polygones purement numériques (mm), groupés par calque. Aucun objet Qt
    n'est conservé ensuite -> peut être passé sans risque à un QThread.

    optimize_path (défaut True) : réordonne les tracés de chaque calque par
    plus proche voisin pour réduire les déplacements G0 (voir
    _optimize_polygon_order) — sans effet sur les calques en mode 'Gravure
    Remplie' (balayage scanline sur toute la zone, l'ordre des tracés n'y
    change rien au trajet réel).
    """
    layers_data = {}
    for layer in layer_manager.layers:
        if not layer.enabled:
            continue
        layers_data[layer.id] = {"layer": layer.to_dict(), "polygons": [], "polygon_groups": []}

    for obj in objects:
        if obj.layer_id not in layers_data:
            continue
        path = obj.world_path()
        polygons = path.toSubpathPolygons(QTransform())
        poly_points = []
        for poly in polygons:
            pts = [(p.x(), p.y()) for p in poly]
            if len(pts) >= 2:
                poly_points.append(pts)
        if poly_points:
            layers_data[obj.layer_id]["polygons"].extend(poly_points)
            # Un groupe par objet : le remplissage applique la règle pair-impair DANS un objet (trous),
            # puis réunit les objets entre eux (voir _scanline_fill_union).
            layers_data[obj.layer_id]["polygon_groups"].append(poly_points)

    if optimize_path:
        for layer_id, data in layers_data.items():
            if data["layer"].get("mode") == "Gravure Remplie":
                continue  # balayage scanline : l'ordre des tracés n'a pas d'effet
            polys = data["polygons"]
            if 1 < len(polys) <= MAX_POLYGONS_FOR_PATH_OPTIMIZATION:
                data["polygons"] = _optimize_polygon_order(polys)

    return layers_data


def _scanline_fill_union(groups, y):
    """Segments remplis à la hauteur y : règle pair-impair à l'intérieur de chaque objet (trous), puis UNION
    des objets. Avant, tous les contours du calque étaient mélangés dans une seule règle pair-impair : deux
    objets qui se chevauchent (traits qui se croisent, lettres rapprochées) s'annulaient là où ils se
    recouvrent et laissaient un vide non gravé."""
    segments = []
    for group in groups:
        segments.extend(_scanline_fill_segments(group, y))
    if len(segments) < 2:
        return segments
    segments.sort()
    merged = [list(segments[0])]
    for a, b in segments[1:]:
        if a <= merged[-1][1] + 1e-9:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [(a, b) for a, b in merged]


def _scanline_fill_segments(polygons, y):
    """Algorithme de balayage (pair-impair) : renvoie les segments [x_debut, x_fin]
    remplis par la ligne horizontale y, toutes contours confondus (gère les trous,
    ex. l'intérieur des lettres 'o', 'a', 'e'...)."""
    xs = []
    for poly in polygons:
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            if y1 == y2:
                continue
            if (y1 <= y < y2) or (y2 <= y < y1):
                t = (y - y1) / (y2 - y1)
                xs.append(x1 + t * (x2 - x1))
    xs.sort()
    segments = []
    for i in range(0, len(xs) - 1, 2):
        if xs[i + 1] - xs[i] > 1e-6:
            segments.append((xs[i], xs[i + 1]))
    return segments


def build_vector_layers_gcode(layers_data, base_offset_x, base_offset_y, h_mm,
                               laser_cmd, s_max, overscan_dist=0.0, safe_cut_order=False, scan_offset=0.0):
    """Construit le G-Code (Phase "Calques Vectoriels") pour tous les calques actifs,
    à partir des données géométriques déjà extraites (voir extract_vector_layer_data).
    Les coordonnées des objets vectoriels sont déjà exprimées dans le repère
    machine (origine bas-gauche, Y croissant vers le haut) via
    VectorObject.world_transform : aucune inversion supplémentaire n'est
    nécessaire ici (contrairement à la gravure image / découpe SVG importée,
    qui restent en haut-gauche/Y descendant).

    overscan_dist (mm) : distance de surbalayage appliquée aux lignes de
    remplissage (mode 'Gravure Remplie'), comme pour la gravure image —
    le laser reste éteint pendant le dépassement de part et d'autre.

    safe_cut_order : graver avant de découper (les calques de découpe passent après les autres) et, dans
    un calque de découpe, couper les contours intérieurs avant ceux qui les contiennent (voir
    vector_order) : une pièce ne bouge plus avant que ses détails soient faits.

    scan_offset : décalage (mm) des lignes de remplissage parcourues en sens retour, pour compenser le jeu
    mécanique et le délai d'allumage du laser (même réglage que pour les images ; sinon les contours des
    remplissages sont en escalier et les petits traits se cassent)."""
    gcode = []
    total_time_seconds = 0.0
    power_samples = []

    def to_gcode_xy(x_mm, y_mm):
        return base_offset_x + x_mm, base_offset_y + y_mm

    items = list(layers_data.items())
    if safe_cut_order:
        items = order_layers_for_cutting(items)
    for layer_id, data in items:
        layer = data["layer"]
        polygons = data["polygons"]
        if not polygons:
            continue
        if safe_cut_order and layer["mode"] == CUT_MODE:
            polygons = order_polygons_inner_first(polygons)

        gcode.append(f"; --- CALQUE '{layer['name']}' [{layer['mode']}] ---")
        if safe_cut_order and layer["mode"] == CUT_MODE:
            gcode.append("; Ordre de découpe : intérieur avant extérieur")
        speed = layer["speed"]
        power_val = int(round((layer["power"] / 100.0) * s_max))
        gcode.append(f"F{speed}")

        if layer["mode"] == "Gravure Remplie":
            ys = [p[1] for poly in polygons for p in poly]
            if not ys:
                continue
            y_min, y_max = min(ys), max(ys)
            step = max(layer["line_interval"], 0.02)
            y = y_min
            line_idx = 0
            groups = data.get("polygon_groups") or [polygons]
            while y <= y_max:
                segments = _scanline_fill_union(groups, y)
                if segments:
                    ordered = segments if line_idx % 2 == 0 else list(reversed(
                        [(b + scan_offset, a + scan_offset) for a, b in segments]))
                    for seg in ordered:
                        sx_mm, ex_mm = seg[0], seg[1]
                        direction = 1.0 if ex_mm >= sx_mm else -1.0
                        real_sx, real_sy = to_gcode_xy(sx_mm, y)
                        real_ex, real_ey = to_gcode_xy(ex_mm, y)

                        if overscan_dist > 0:
                            pre_x, pre_y = to_gcode_xy(
                                sx_mm - direction * overscan_dist, y
                            )
                            post_x, post_y = to_gcode_xy(
                                ex_mm + direction * overscan_dist, y
                            )

                            # Déplacement avant balayage avec laser éteint.
                            gcode.append(
                                f"G0 X{pre_x:.3f} Y{pre_y:.3f}"
                            )
                            gcode.append(f"{laser_cmd} S0")
                            gcode.append(
                                f"G1 X{real_sx:.3f} Y{real_sy:.3f} F{speed}"
                            )

                            # Gravure du segment réel.
                            gcode.append(f"{laser_cmd} S{power_val}")
                            gcode.append(
                                f"G1 X{real_ex:.3f} Y{real_ey:.3f} F{speed}"
                            )

                            # Sortie de balayage avec laser éteint.
                            gcode.append(f"{laser_cmd} S0")
                            gcode.append(
                                f"G1 X{post_x:.3f} Y{post_y:.3f} F{speed}"
                            )

                            total_time_seconds += (
                                abs(post_x - pre_x) / max(speed, 1)
                            ) * 60.0
                        else:
                            gcode.append(
                                f"G0 X{real_sx:.3f} Y{real_sy:.3f}"
                            )
                            gcode.append(f"{laser_cmd} S{power_val}")
                            gcode.append(
                                f"G1 X{real_ex:.3f} Y{real_ey:.3f} F{speed}"
                            )

                            total_time_seconds += (
                                abs(real_ex - real_sx) / max(speed, 1)
                            ) * 60.0

                            # Prépare le prochain déplacement avec le laser
                            # éteint, sans arrêter complètement le mode M4.
                            gcode.append(f"{laser_cmd} S0")

                        power_samples.append(layer["power"])
                y += step
                line_idx += 1
        else:
            # Découpe ou Marquage : contour(s) uniquement
            for pass_num in range(layer["passes"]):
                if layer["passes"] > 1:
                    gcode.append(f"; Passe {pass_num + 1}/{layer['passes']}")
                for poly in polygons:
                    if len(poly) < 2:
                        continue
                    sx, sy = to_gcode_xy(*poly[0])
                    gcode.append(f"G0 X{sx:.3f} Y{sy:.3f}")
                    gcode.append(f"{laser_cmd} S{power_val}")
                    cx, cy = sx, sy
                    pts = poly + [poly[0]] if poly[0] != poly[-1] else poly
                    for (px, py) in pts[1:]:
                        nx, ny = to_gcode_xy(px, py)
                        gcode.append(f"G1 X{nx:.3f} Y{ny:.3f}")
                        total_time_seconds += (math.hypot(nx - cx, ny - cy) / max(speed, 1)) * 60.0
                        power_samples.append(layer["power"])
                        cx, cy = nx, ny
                    gcode.append("M5")

    return gcode, total_time_seconds, power_samples
